// ===== MAIN APPLICATION FILE =====
// EduGhana - Education Platform for Ghanaian Students

import { AuthModule } from './modules/auth.js';
import { NotesModule } from './modules/notes.js';
import { QuizModule } from './modules/quiz.js';
import { ResourcesModule } from './modules/resources.js';
import { UIModule } from './modules/ui.js';
import { ToastModule } from './modules/toast.js';
import { CoursesModule } from './modules/courses.js';

class EduGhanaApp {
    constructor() {
        this.modules = {};
        this.currentUser = null;
        this.init();
    }

    async init() {
        try {
            // Initialize all modules
            this.modules.auth = new AuthModule();
            this.modules.notes = new NotesModule();
            this.modules.quiz = new QuizModule();
            this.modules.resources = new ResourcesModule();
            this.modules.ui = new UIModule();
            this.modules.toast = new ToastModule();
            this.modules.courses = new CoursesModule();

            // Initialize UI components
            this.modules.ui.init();
            
            // Check authentication status
            await this.checkAuthStatus();
            
            // Initialize navigation
            this.initNavigation();
            
            // Initialize theme
            this.initTheme();
            
            // Update stats on homepage
            this.updateStats();
            
            // Initialize page-specific functionality
            this.initPageSpecific();
            
            console.log('EduGhana app initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize EduGhana app:', error);
            this.modules.toast.show('Failed to initialize app', 'error');
        }
    }

    async checkAuthStatus() {
        try {
            this.currentUser = await this.modules.auth.getCurrentUser();
            this.updateNavigation();
        } catch (error) {
            console.log('No authenticated user found');
        }
    }

    updateNavigation() {
        const authSection = document.getElementById('nav-auth');
        
        if (this.currentUser) {
            authSection.innerHTML = `
                <div class="user-menu">
                    <span class="user-name">${this.currentUser.name}</span>
                    <button class="btn btn-outline" onclick="window.edughanaApp.handleLogout()">Logout</button>
                </div>
            `;
        } else {
            authSection.innerHTML = `
                <a href="login.html" class="btn btn-outline">Login</a>
                <a href="register.html" class="btn btn-primary">Register</a>
            `;
        }
    }

    async handleLogout() {
        try {
            await this.modules.auth.logout();
            this.currentUser = null;
            this.updateNavigation();
            this.modules.toast.show('Logged out successfully', 'success');
            
            // Redirect to home if on protected page
            if (window.location.pathname.endsWith('notes.html')) {
                window.location.href = 'index.html';
            }
        } catch (error) {
            console.error('Logout failed:', error);
            this.modules.toast.show('Logout failed', 'error');
        }
    }

    initNavigation() {
        const navToggle = document.getElementById('nav-toggle');
        const navMenu = document.getElementById('nav-menu');

        if (navToggle && navMenu) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
            });

            // Close mobile menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.remove('active');
                }
            });

            // Close mobile menu when clicking on nav links
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('active');
                });
            });
        }

        // Handle auth-required links
        const authRequiredLinks = document.querySelectorAll('.auth-required');
        authRequiredLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                if (!this.currentUser) {
                    e.preventDefault();
                    this.modules.toast.show('Please login to access this feature', 'warning');
                    window.location.href = 'login.html';
                }
            });
        });
    }

    initTheme() {
        const themeToggle = document.getElementById('theme-toggle');
        const themeIcon = document.querySelector('.theme-icon');
        
        if (themeToggle) {
            // Load saved theme
            const savedTheme = localStorage.getItem('edughana_theme') || 'light';
            document.documentElement.setAttribute('data-theme', savedTheme);
            this.updateThemeIcon(themeIcon, savedTheme);
            
            // Theme toggle event
            themeToggle.addEventListener('click', () => {
                const currentTheme = document.documentElement.getAttribute('data-theme');
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.documentElement.setAttribute('data-theme', newTheme);
                localStorage.setItem('edughana_theme', newTheme);
                this.updateThemeIcon(themeIcon, newTheme);
            });
        }
    }

    updateThemeIcon(iconElement, theme) {
        if (iconElement) {
            iconElement.textContent = theme === 'dark' ? '☀️' : '🌙';
        }
    }

    updateStats() {
        try {
            // Update user count
            const totalUsers = this.modules.auth.getTotalUsers();
            const totalUsersElement = document.getElementById('total-users');
            if (totalUsersElement) {
                totalUsersElement.textContent = totalUsers;
            }

            // Update notes count for current user
            const totalNotesElement = document.getElementById('total-notes');
            if (totalNotesElement && this.currentUser) {
                const userNotes = this.modules.notes.getUserNotes(this.currentUser.id);
                totalNotesElement.textContent = userNotes.length;
            }

            // Update quizzes count for current user
            const totalQuizzesElement = document.getElementById('total-quizzes');
            if (totalQuizzesElement && this.currentUser) {
                const userScores = this.modules.quiz.getUserScores(this.currentUser.id);
                totalQuizzesElement.textContent = Object.keys(userScores).length;
            }
        } catch (error) {
            console.log('Stats update failed:', error);
        }
    }

    initPageSpecific() {
        const currentPage = window.location.pathname.split('/').pop();
        
        switch (currentPage) {
            case 'courses.html':
                this.initCoursesPage();
                break;
            case 'course-detail.html':
                this.initCourseDetailPage();
                break;
            case 'quiz.html':
                this.initQuizPage();
                break;
            case 'notes.html':
                this.initNotesPage();
                break;
            case 'resources.html':
                this.initResourcesPage();
                break;
            case 'login.html':
                this.initLoginPage();
                break;
            case 'register.html':
                this.initRegisterPage();
                break;
            case 'about.html':
                this.initAboutPage();
                break;
            case 'contact.html':
                this.initContactPage();
                break;
        }
    }

    initCoursesPage() {
        if (this.modules.ui) {
            this.modules.ui.initCoursesPage();
        }
    }

    initCourseDetailPage() {
        if (this.modules.ui) {
            this.modules.ui.initCourseDetailPage();
        }
    }

    initQuizPage() {
        if (this.modules.ui) {
            this.modules.ui.initQuizPage();
        }
    }

    initNotesPage() {
        if (this.modules.ui) {
            this.modules.ui.initNotesPage();
        }
    }

    initResourcesPage() {
        if (this.modules.ui) {
            this.modules.ui.initResourcesPage();
        }
    }

    initLoginPage() {
        if (this.modules.ui) {
            this.modules.ui.initLoginPage();
        }
    }

    initRegisterPage() {
        if (this.modules.ui) {
            this.modules.ui.initRegisterPage();
        }
    }

    initAboutPage() {
        if (this.modules.ui) {
            this.modules.ui.initAboutPage();
        }
    }

    initContactPage() {
        if (this.modules.ui) {
            this.modules.ui.initContactPage();
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.edughanaApp = new EduGhanaApp();
});

// Export for use in other modules
export { EduGhanaApp };
