// ===== UI MODULE =====
// Handles all page-specific UI functionality

export class UIModule {
    constructor() {
        this.currentUser = null;
        this.courses = [];
        this.init();
    }

    init() {
        // Initialize basic UI functionality
        this.initModals();
        this.initForms();
    }

    // Get sample courses data
    getSampleCourses() {
        return [
            {
                id: 'mathematics',
                title: 'Mathematics',
                description: 'Comprehensive coverage of SHS and University Mathematics including Algebra, Geometry, Calculus, and Statistics. Perfect for WASSCE preparation.',
                level: 'SHS/University',
                subject: 'Mathematics',
                image: '📐',
                duration: '12 weeks',
                topics: ['Algebra', 'Geometry', 'Calculus', 'Statistics', 'Trigonometry']
            },
            {
                id: 'english',
                title: 'English Language & Literature',
                description: 'Master English grammar, literature analysis, and writing skills. Essential for academic success and WASSCE English examination.',
                level: 'SHS/University',
                subject: 'English',
                image: '📚',
                duration: '10 weeks',
                topics: ['Grammar', 'Literature', 'Writing', 'Comprehension', 'Poetry']
            },
            {
                id: 'ict',
                title: 'Information & Communication Technology',
                description: 'Learn programming fundamentals, computer science concepts, and practical ICT skills for the digital age.',
                level: 'SHS/University',
                subject: 'ICT',
                image: '💻',
                duration: '14 weeks',
                topics: ['Programming', 'Web Development', 'Databases', 'Networking', 'Cybersecurity']
            },
            {
                id: 'science',
                title: 'Integrated Science',
                description: 'Explore Physics, Chemistry, and Biology concepts with hands-on experiments and real-world applications.',
                level: 'SHS',
                subject: 'Science',
                image: '🔬',
                duration: '16 weeks',
                topics: ['Physics', 'Chemistry', 'Biology', 'Experiments', 'Scientific Method']
            },
            {
                id: 'social-studies',
                title: 'Social Studies',
                description: 'Study Ghana\'s history, geography, economics, and government. Understand your country\'s past and present.',
                level: 'SHS',
                subject: 'Social Studies',
                image: '🌍',
                duration: '12 weeks',
                topics: ['Ghana History', 'Geography', 'Economics', 'Government', 'Culture']
            },
            {
                id: 'programming',
                title: 'Programming Fundamentals',
                description: 'Introduction to programming concepts using Python. Learn variables, loops, functions, and problem-solving.',
                level: 'University',
                subject: 'Computer Science',
                image: '🐍',
                duration: '8 weeks',
                topics: ['Python Basics', 'Variables', 'Loops', 'Functions', 'Data Structures']
            },
            {
                id: 'data-structures',
                title: 'Data Structures & Algorithms',
                description: 'Advanced programming concepts covering arrays, linked lists, trees, graphs, and algorithm analysis.',
                level: 'University',
                subject: 'Computer Science',
                image: '📊',
                duration: '10 weeks',
                topics: ['Arrays', 'Linked Lists', 'Trees', 'Graphs', 'Algorithm Analysis']
            },
            {
                id: 'business',
                title: 'Business Studies',
                description: 'Learn business principles, entrepreneurship, and management concepts relevant to Ghana\'s economy.',
                level: 'SHS/University',
                subject: 'Business',
                image: '💼',
                duration: '12 weeks',
                topics: ['Business Principles', 'Entrepreneurship', 'Management', 'Marketing', 'Finance']
            }
        ];
    }

    // Initialize modal functionality
    initModals() {
        // Close modals when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-overlay')) {
                this.closeModal(e.target);
            }
        });

        // Close modals with Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    // Initialize form functionality
    initForms() {
        // Auto-save form data
        document.addEventListener('input', (e) => {
            if (e.target.classList.contains('auto-save')) {
                this.autoSaveForm(e.target.closest('form'));
            }
        });
    }

    // Modal functions
    showModal(content, title = '') {
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'modal-overlay';
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        
        if (title) {
            const modalHeader = document.createElement('div');
            modalHeader.className = 'modal-header';
            
            const modalTitle = document.createElement('h3');
            modalTitle.className = 'modal-title';
            modalTitle.textContent = title;
            
            const modalClose = document.createElement('button');
            modalClose.className = 'modal-close';
            modalClose.innerHTML = '&times;';
            modalClose.addEventListener('click', () => this.closeModal(modalOverlay));
            
            modalHeader.appendChild(modalTitle);
            modalHeader.appendChild(modalClose);
            modal.appendChild(modalHeader);
        }
        
        const modalBody = document.createElement('div');
        modalBody.className = 'modal-body';
        modalBody.innerHTML = content;
        modal.appendChild(modalBody);
        
        modalOverlay.appendChild(modal);
        document.body.appendChild(modalOverlay);
        
        // Focus first input if exists
        const firstInput = modal.querySelector('input, textarea, select');
        if (firstInput) {
            firstInput.focus();
        }
        
        return modalOverlay;
    }

    closeModal(modalOverlay) {
        if (modalOverlay && modalOverlay.parentNode) {
            modalOverlay.parentNode.removeChild(modalOverlay);
        }
    }

    closeAllModals() {
        const modals = document.querySelectorAll('.modal-overlay');
        modals.forEach(modal => this.closeModal(modal));
    }

    // Auto-save form data
    autoSaveForm(form) {
        if (!form) return;
        
        const formData = new FormData(form);
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        
        const formId = form.id || 'form_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem(`edughana_form_${formId}`, JSON.stringify(data));
    }

    // Restore form data
    restoreFormData(form) {
        if (!form) return;
        
        const formId = form.id || 'form_' + Math.random().toString(36).substr(2, 9);
        const savedData = localStorage.getItem(`edughana_form_${formId}`);
        
        if (savedData) {
            try {
                const data = JSON.parse(savedData);
                for (let [key, value] of Object.entries(data)) {
                    const input = form.querySelector(`[name="${key}"]`);
                    if (input) {
                        input.value = value;
                    }
                }
            } catch (error) {
                console.error('Error restoring form data:', error);
            }
        }
    }

    // Initialize courses page
    initCoursesPage() {
        // Get courses from the courses module
        this.courses = window.edughanaApp.modules.courses.getAllCourses();
        this.renderCourses();
        this.initCourseFilters();
        this.initCourseSearch();
        this.initOnlineSearch();
    }

    // Render courses grid
    renderCourses() {
        const coursesGrid = document.querySelector('.courses-grid');
        if (!coursesGrid) return;

        coursesGrid.innerHTML = this.courses.map(course => `
            <div class="course-card">
                <div class="course-image">
                    ${course.image}
                </div>
                <div class="course-content">
                    <h3 class="course-title">${course.title}</h3>
                    <p class="course-description">${course.description}</p>
                    <div class="course-meta">
                        <span class="course-level">${course.level}</span>
                        <span class="course-subject">${course.subject}</span>
                    </div>
                    <div class="course-actions">
                        <a href="/course-detail.html?id=${course.id}" class="btn btn-primary">View Course</a>
                        <a href="/quiz.html?course=${course.id}" class="btn btn-outline">Take Quiz</a>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Initialize course filters
    initCourseFilters() {
        const levelFilter = document.getElementById('level-filter');
        const subjectFilter = document.getElementById('subject-filter');
        
        if (levelFilter) {
            levelFilter.addEventListener('change', () => this.applyFilters());
        }
        
        if (subjectFilter) {
            subjectFilter.addEventListener('change', () => this.applyFilters());
        }
    }

    // Initialize course search
    initCourseSearch() {
        const searchInput = document.getElementById('search-filter');
        if (searchInput) {
            searchInput.addEventListener('input', () => this.applyFilters());
        }
    }

    // Initialize online course search
    initOnlineSearch() {
        const onlineSearchForm = document.getElementById('online-search-form');
        if (onlineSearchForm) {
            onlineSearchForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                await this.performOnlineSearch();
            });
        }
        
        // Initialize trending topics
        this.initTrendingTopics();
    }

    // Initialize trending topics
    initTrendingTopics() {
        const trendingContainer = document.querySelector('.trending-topics-grid');
        if (!trendingContainer) return;

        const trendingTopics = window.edughanaApp.modules.courses.getTrendingTopics();
        
        trendingContainer.innerHTML = trendingTopics.map(topic => `
            <button class="trending-topic" onclick="window.edughanaApp.modules.ui.searchTrendingTopic('${topic}')">
                ${topic}
            </button>
        `).join('');
    }

    // Search for trending topic
    async searchTrendingTopic(topic) {
        const searchInput = document.getElementById('online-search-input');
        if (searchInput) {
            searchInput.value = topic;
            await this.performOnlineSearch();
        }
    }

    // Apply all filters and search
    applyFilters() {
        const levelFilter = document.getElementById('level-filter');
        const subjectFilter = document.getElementById('subject-filter');
        const searchInput = document.getElementById('search-filter');
        
        const level = levelFilter ? levelFilter.value : 'all';
        const subject = subjectFilter ? subjectFilter.value : 'all';
        const search = searchInput ? searchInput.value.toLowerCase() : '';
        
        let filteredCourses = [...this.courses];
        
        // Filter by level
        if (level !== 'all') {
            filteredCourses = filteredCourses.filter(course => course.level === level);
        }
        
        // Filter by subject
        if (subject !== 'all') {
            filteredCourses = filteredCourses.filter(course => course.subject === subject);
        }
        
        // Filter by search
        if (search) {
            filteredCourses = filteredCourses.filter(course => 
                course.title.toLowerCase().includes(search) ||
                course.description.toLowerCase().includes(search) ||
                course.subject.toLowerCase().includes(search) ||
                course.topics.some(topic => topic.toLowerCase().includes(search))
            );
        }
        
        this.renderFilteredCourses(filteredCourses);
    }

    // Perform online course search
    async performOnlineSearch() {
        const searchInput = document.getElementById('online-search-input');
        const resultsContainer = document.getElementById('online-search-results');
        
        if (!searchInput || !resultsContainer) return;

        const query = searchInput.value.trim();
        if (!query) return;

        try {
            resultsContainer.innerHTML = '<div class="loading">🔍 Searching online for courses...</div>';
            
            // Get filters if available
            const levelFilter = document.getElementById('level-filter');
            const subjectFilter = document.getElementById('subject-filter');
            
            const filters = {};
            if (levelFilter && levelFilter.value !== 'all') filters.level = levelFilter.value;
            if (subjectFilter && subjectFilter.value !== 'all') filters.subject = subjectFilter.value;
            
            // Search online courses
            const onlineResults = await window.edughanaApp.modules.courses.searchOnlineCourses(query, filters);
            
            // Update courses list with new results
            this.courses = window.edughanaApp.modules.courses.getAllCourses();
            
            if (onlineResults.length > 0) {
                resultsContainer.innerHTML = `
                    <div class="online-search-header">
                        <h3>🌐 Online Course Results for "${query}"</h3>
                        <p>Found ${onlineResults.length} courses from external sources</p>
                    </div>
                    <div class="online-courses-grid">
                        ${onlineResults.map(course => this.renderOnlineCourseCard(course)).join('')}
                    </div>
                `;
                
                // Re-render courses to include online results
                this.renderCourses();
            } else {
                resultsContainer.innerHTML = `
                    <div class="no-online-results">
                        <p>No online courses found for "${query}". Try different keywords or check your spelling.</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Online search failed:', error);
            resultsContainer.innerHTML = `
                <div class="search-error">
                    <p>❌ Failed to search online courses. Please try again.</p>
                    <p class="error-details">${error.message}</p>
                </div>
            `;
        }
    }

    // Render online course card
    renderOnlineCourseCard(course) {
        return `
            <div class="online-course-card" data-course-id="${course.id}">
                <div class="course-header">
                    <div class="course-image">${course.image}</div>
                    <div class="course-source">${course.source}</div>
                </div>
                <div class="course-content">
                    <h4 class="course-title">${course.title}</h4>
                    <p class="course-description">${course.description}</p>
                    <div class="course-meta">
                        <span class="course-level">${course.level}</span>
                        <span class="course-subject">${course.subject}</span>
                        ${course.author ? `<span class="course-author">by ${course.author}</span>` : ''}
                    </div>
                    ${course.topics && course.topics.length > 0 ? `
                        <div class="course-topics">
                            <strong>Topics:</strong> ${course.topics.slice(0, 3).join(', ')}${course.topics.length > 3 ? '...' : ''}
                        </div>
                    ` : ''}
                </div>
                <div class="course-actions">
                    ${course.url ? `<a href="${course.url}" target="_blank" rel="noopener" class="btn btn-primary">View Course</a>` : ''}
                    <button class="btn btn-outline" onclick="window.edughanaApp.modules.ui.addToLocalCourses('${course.id}')">Save to Library</button>
                </div>
            </div>
        `;
    }

    // Add online course to local library
    addToLocalCourses(courseId) {
        try {
            const course = window.edughanaApp.modules.courses.getCourseById(courseId);
            if (!course) {
                window.edughanaApp.modules.toast.show('Course not found', 'error');
                return;
            }

            // Check if course is already in local library
            const localCourses = window.edughanaApp.modules.courses.courses;
            const isAlreadyLocal = localCourses.some(c => c.id === courseId);
            
            if (isAlreadyLocal) {
                window.edughanaApp.modules.toast.show('Course is already in your library', 'info');
                return;
            }

            // Add course to local library
            const localCourse = {
                ...course,
                source: 'local',
                savedAt: new Date().toISOString()
            };

            // Save to localStorage for persistence
            const savedCourses = JSON.parse(localStorage.getItem('edughana_saved_courses') || '[]');
            savedCourses.push(localCourse);
            localStorage.setItem('edughana_saved_courses', JSON.stringify(savedCourses));

            // Update courses module
            window.edughanaApp.modules.courses.courses.push(localCourse);

            // Update UI
            this.courses = window.edughanaApp.modules.courses.getAllCourses();
            this.renderCourses();

            window.edughanaApp.modules.toast.show('Course saved to your library!', 'success');
            
            // Update the button to show it's saved
            const courseCard = document.querySelector(`[data-course-id="${courseId}"]`);
            if (courseCard) {
                const saveButton = courseCard.querySelector('.btn-outline');
                if (saveButton) {
                    saveButton.textContent = '✓ Saved';
                    saveButton.disabled = true;
                    saveButton.classList.add('saved');
                }
            }

        } catch (error) {
            console.error('Failed to save course:', error);
            window.edughanaApp.modules.toast.show('Failed to save course', 'error');
        }
    }

    // Render filtered courses
    renderFilteredCourses(filteredCourses) {
        const coursesGrid = document.querySelector('.courses-grid');
        if (!coursesGrid) return;

        if (filteredCourses.length === 0) {
            coursesGrid.innerHTML = `
                <div class="no-courses-found">
                    <div class="no-courses-icon">🔍</div>
                    <h3>No courses found</h3>
                    <p>Try adjusting your search criteria or filters</p>
                    <button class="btn btn-primary" onclick="this.clearFilters()">Clear All Filters</button>
                </div>
            `;
            return;
        }

        coursesGrid.innerHTML = filteredCourses.map(course => `
            <div class="course-card">
                <div class="course-image">
                    ${course.image}
                </div>
                <div class="course-content">
                    <h3 class="course-title">${course.title}</h3>
                    <p class="course-description">${course.description}</p>
                    <div class="course-meta">
                        <span class="course-level">${course.level}</span>
                        <span class="course-subject">${course.subject}</span>
                    </div>
                    <div class="course-topics">
                        <strong>Topics:</strong> ${course.topics.slice(0, 3).join(', ')}${course.topics.length > 3 ? '...' : ''}
                    </div>
                    <div class="course-actions">
                        <a href="course-detail.html?id=${course.id}" class="btn btn-primary">View Course</a>
                        <a href="quiz.html?course=${course.id}" class="btn btn-outline">Take Quiz</a>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Clear all filters
    clearFilters() {
        const levelFilter = document.getElementById('level-filter');
        const subjectFilter = document.getElementById('subject-filter');
        const searchInput = document.getElementById('search-filter');
        
        if (levelFilter) levelFilter.value = 'all';
        if (subjectFilter) subjectFilter.value = 'all';
        if (searchInput) searchInput.value = '';
        
        this.renderCourses();
    }

    // Initialize course detail page
    initCourseDetailPage() {
        const urlParams = new URLSearchParams(window.location.search);
        const courseId = urlParams.get('id');
        
        if (courseId) {
            const course = this.courses.find(c => c.id === courseId);
            if (course) {
                this.renderCourseDetail(course);
            } else {
                this.showCourseNotFound();
            }
        } else {
            this.showCourseNotFound();
        }
    }

    // Render course detail
    renderCourseDetail(course) {
        const container = document.querySelector('.course-detail-container');
        if (!container) return;

        container.innerHTML = `
            <div class="course-detail-header">
                <h1>${course.title}</h1>
                <p class="course-description">${course.description}</p>
                <div class="course-meta">
                    <span class="course-level">${course.level}</span>
                    <span class="course-subject">${course.subject}</span>
                    <span class="course-duration">${course.duration}</span>
                </div>
            </div>
            
            <div class="course-syllabus">
                <h2>Course Syllabus</h2>
                <ul class="syllabus-list">
                    ${course.topics.map(topic => `<li>${topic}</li>`).join('')}
                </ul>
            </div>
            
            <div class="course-actions">
                <a href="/quiz.html?course=${course.id}" class="btn btn-primary btn-large">Start Quiz</a>
                <a href="/courses.html" class="btn btn-outline">Back to Courses</a>
            </div>
            
            <div class="related-courses">
                <h2>Related Courses</h2>
                <div class="related-courses-grid">
                    ${this.getRelatedCourses(course).map(relatedCourse => `
                        <div class="related-course-card">
                            <h3>${relatedCourse.title}</h3>
                            <p>${relatedCourse.description.substring(0, 100)}...</p>
                            <a href="/course-detail.html?id=${relatedCourse.id}" class="btn btn-outline">View Course</a>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // Get related courses
    getRelatedCourses(course) {
        return this.courses
            .filter(c => c.id !== course.id && (c.subject === course.subject || c.level === course.level))
            .slice(0, 3);
    }

    // Show course not found
    showCourseNotFound() {
        const container = document.querySelector('.course-detail-container');
        if (!container) return;

        container.innerHTML = `
            <div class="course-not-found">
                <h1>Course Not Found</h1>
                <p>The course you're looking for doesn't exist.</p>
                <a href="/courses.html" class="btn btn-primary">Browse All Courses</a>
            </div>
        `;
    }

    // Initialize quiz page
    initQuizPage() {
        const urlParams = new URLSearchParams(window.location.search);
        const courseId = urlParams.get('course');
        
        if (courseId) {
            this.startQuiz(courseId);
        } else {
            this.showCourseSelection();
        }
    }

    // Show course selection for quiz
    showCourseSelection() {
        const container = document.querySelector('.quiz-container');
        if (!container) return;

        container.innerHTML = `
            <div class="quiz-course-selection">
                <h1>Select a Course for Quiz</h1>
                <p>Choose a course to start your quiz:</p>
                <div class="course-selection-grid">
                    ${this.courses.map(course => `
                        <div class="course-selection-card">
                            <div class="course-icon">${course.image}</div>
                            <h3>${course.title}</h3>
                            <p>${course.description.substring(0, 100)}...</p>
                            <a href="/quiz.html?course=${course.id}" class="btn btn-primary">Start Quiz</a>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // Start quiz
    startQuiz(courseId) {
        // This will be implemented when we integrate with the QuizModule
        console.log(`Starting quiz for course: ${courseId}`);
    }

    // Initialize notes page
    initNotesPage() {
        // Check if user is authenticated
        if (!window.edughanaApp || !window.edughanaApp.currentUser) {
            window.location.href = 'login.html';
            return;
        }

        this.currentUser = window.edughanaApp.currentUser;
        this.renderNotes();
        this.initNotesToolbar();
    }

    // Render notes
    renderNotes() {
        const notesGrid = document.querySelector('.notes-grid');
        if (!notesGrid) return;

        const notes = window.edughanaApp.modules.notes.getUserNotes(this.currentUser.id);
        
        if (notes.length === 0) {
            notesGrid.innerHTML = `
                <div class="no-notes">
                    <h3>No Notes Yet</h3>
                    <p>Start creating your study notes to organize your learning!</p>
                    <button class="btn btn-primary" onclick="this.showAddNoteModal()">Create Your First Note</button>
                </div>
            `;
        } else {
            notesGrid.innerHTML = notes.map(note => `
                <div class="note-card" data-note-id="${note.id}">
                    <div class="note-header">
                        <h3 class="note-title">${note.title}</h3>
                        <span class="note-subject">${note.subject}</span>
                    </div>
                    <div class="note-content">
                        <p>${note.content.substring(0, 150)}${note.content.length > 150 ? '...' : ''}</p>
                    </div>
                    <div class="note-footer">
                        <span class="note-date">${new Date(note.updatedAt).toLocaleDateString()}</span>
                        <div class="note-actions">
                            <button class="btn btn-outline btn-sm" onclick="this.editNote('${note.id}')">Edit</button>
                            <button class="btn btn-outline btn-sm" onclick="this.deleteNote('${note.id}')">Delete</button>
                        </div>
                    </div>
                </div>
            `).join('');
        }
    }

    // Initialize notes toolbar
    initNotesToolbar() {
        const toolbar = document.querySelector('.notes-toolbar');
        if (!toolbar) return;

        toolbar.innerHTML = `
            <button class="btn btn-primary" onclick="this.showAddNoteModal()">Add Note</button>
            <input type="text" class="form-input" placeholder="Search notes..." onkeyup="this.searchNotes(this.value)">
            <select class="form-input" onchange="this.filterNotesBySubject(this.value)">
                <option value="all">All Subjects</option>
                ${this.getUserSubjects().map(subject => `<option value="${subject}">${subject}</option>`).join('')}
            </select>
            <select class="form-input" onchange="this.sortNotes(this.value)">
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
                <option value="title">By Title</option>
                <option value="subject">By Subject</option>
            </select>
        `;
    }

    // Get user subjects
    getUserSubjects() {
        if (!window.edughanaApp || !this.currentUser) return [];
        return window.edughanaApp.modules.notes.getUserSubjects(this.currentUser.id);
    }

    // Initialize resources page
    initResourcesPage() {
        this.initResourcesSearch();
        this.showTrendingTopics();
    }

    // Initialize resources search
    initResourcesSearch() {
        const searchForm = document.querySelector('#resources-search-form');
        if (!searchForm) return;

        searchForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.performResourcesSearch();
        });
    }

    // Perform resources search
    async performResourcesSearch() {
        const searchInput = document.querySelector('#resources-search-input');
        const resultsContainer = document.querySelector('#resources-results');
        
        if (!searchInput || !resultsContainer) return;

        const query = searchInput.value.trim();
        if (!query) return;

        try {
            resultsContainer.innerHTML = '<div class="loading">Searching...</div>';
            
            const results = await window.edughanaApp.modules.resources.searchResources(query, 5);
            
            if (results.length > 0) {
                resultsContainer.innerHTML = results.map(result => `
                    <div class="resource-result">
                        <h3>${result.title}</h3>
                        <p>${result.snippet}</p>
                        <div class="resource-meta">
                            <span class="resource-source">${result.source}</span>
                            <span class="resource-type">${result.type}</span>
                        </div>
                        <a href="${result.link}" target="_blank" rel="noopener" class="btn btn-primary">Read More</a>
                    </div>
                `).join('');
            } else {
                resultsContainer.innerHTML = '<div class="no-results">No resources found for your search.</div>';
            }
        } catch (error) {
            resultsContainer.innerHTML = '<div class="error">Failed to search resources. Please try again.</div>';
        }
    }

    // Show trending topics
    showTrendingTopics() {
        const trendingContainer = document.querySelector('#trending-topics');
        if (!trendingContainer) return;

        const topics = window.edughanaApp.modules.resources.getTrendingTopics();
        
        trendingContainer.innerHTML = `
            <h3>Trending Topics</h3>
            <div class="trending-topics-grid">
                ${topics.map(topic => `
                    <button class="trending-topic" onclick="this.searchTopic('${topic}')">${topic}</button>
                `).join('')}
            </div>
        `;
    }

    // Search topic
    async searchTopic(topic) {
        const searchInput = document.querySelector('#resources-search-input');
        if (searchInput) {
            searchInput.value = topic;
            await this.performResourcesSearch();
        }
    }

    // Initialize login page
    initLoginPage() {
        const loginForm = document.querySelector('#login-form');
        if (!loginForm) return;

        // Add demo user button
        this.addDemoUserButton();
        
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.submitLogin(loginForm);
        });
    }

    // Add demo user button
    addDemoUserButton() {
        const formContainer = document.querySelector('.login-container');
        if (!formContainer) return;

        const demoButton = document.createElement('button');
        demoButton.type = 'button';
        demoButton.className = 'btn btn-outline demo-user-btn';
        demoButton.textContent = 'Try Demo User';
        demoButton.onclick = () => this.fillDemoCredentials();

        const form = formContainer.querySelector('form');
        if (form) {
            form.parentNode.insertBefore(demoButton, form.nextSibling);
        }
    }

    // Fill demo credentials
    fillDemoCredentials() {
        const emailInput = document.querySelector('input[name="email"]');
        const passwordInput = document.querySelector('input[name="password"]');
        
        if (emailInput && passwordInput) {
            emailInput.value = 'demo@edughana.com';
            passwordInput.value = 'demo123';
        }
    }

    // Submit login
    async submitLogin(form) {
        const formData = new FormData(form);
        const email = formData.get('email');
        const password = formData.get('password');

        try {
            const result = await window.edughanaApp.modules.auth.login(email, password);
            
            if (result.success) {
                window.edughanaApp.modules.toast.show('Login successful!', 'success');
                window.location.href = 'dashboard.html';
            } else {
                window.edughanaApp.modules.toast.show(result.error, 'error');
            }
        } catch (error) {
            window.edughanaApp.modules.toast.show('Login failed', 'error');
        }
    }

    // Initialize register page
    initRegisterPage() {
        const registerForm = document.querySelector('#register-form');
        if (!registerForm) return;

        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.submitRegister(registerForm);
        });
    }

    // Submit register
    async submitRegister(form) {
        const formData = new FormData(form);
        const userData = {
            name: formData.get('name'),
            email: formData.get('email'),
            password: formData.get('password')
        };

        try {
            const result = await window.edughanaApp.modules.auth.register(userData);
            
            if (result.success) {
                window.edughanaApp.modules.toast.show('Registration successful! Welcome to EduGhana!', 'success');
                window.location.href = 'dashboard.html';
            } else {
                window.edughanaApp.modules.toast.show(result.error, 'error');
            }
        } catch (error) {
            window.edughanaApp.modules.toast.show('Registration failed', 'error');
        }
    }

    // Initialize about page
    initAboutPage() {
        this.initFAQAccordion();
    }

    // Initialize FAQ accordion
    initFAQAccordion() {
        const faqContainer = document.querySelector('.faq-container');
        if (!faqContainer) return;

        const faqs = [
            {
                question: 'What is EduGhana?',
                answer: 'EduGhana is a comprehensive educational platform designed specifically for Ghanaian students. We provide study materials, interactive quizzes, note-taking tools, and quick research capabilities to support both SHS and University students.'
            },
            {
                question: 'Is EduGhana free to use?',
                answer: 'Yes! EduGhana is completely free to use. We believe in making quality education accessible to all Ghanaian students.'
            },
            {
                question: 'What subjects are covered?',
                answer: 'We cover a wide range of subjects including Mathematics, English, ICT, Science, Social Studies, and more. Our content is aligned with Ghana\'s educational curriculum.'
            },
            {
                question: 'How do I get started?',
                answer: 'Simply register for a free account, browse our courses, take quizzes, and start creating your study notes. You can also use our Quick Research feature to find additional learning resources.'
            },
            {
                question: 'Can I use EduGhana on my phone?',
                answer: 'Absolutely! EduGhana is fully responsive and works great on all devices including smartphones, tablets, and desktop computers.'
            }
        ];

        faqContainer.innerHTML = faqs.map((faq, index) => `
            <div class="faq-item">
                <button class="faq-question" onclick="this.toggleFAQ(${index})">
                    ${faq.question}
                    <span class="faq-toggle">+</span>
                </button>
                <div class="faq-answer" id="faq-answer-${index}">
                    <p>${faq.answer}</p>
                </div>
            </div>
        `).join('');
    }

    // Toggle FAQ
    toggleFAQ(index) {
        const answer = document.getElementById(`faq-answer-${index}`);
        const toggle = event.target.querySelector('.faq-toggle');
        
        if (answer.style.display === 'block') {
            answer.style.display = 'none';
            toggle.textContent = '+';
        } else {
            answer.style.display = 'block';
            toggle.textContent = '−';
        }
    }

    // Initialize contact page
    initContactPage() {
        const contactForm = document.querySelector('#contact-form');
        if (!contactForm) return;

        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.submitContact(contactForm);
        });
    }

    // Submit contact form
    async submitContact(form) {
        const formData = new FormData(form);
        const contactData = {
            name: formData.get('name'),
            email: formData.get('email'),
            message: formData.get('message')
        };

        // Simple validation
        if (!contactData.name || !contactData.email || !contactData.message) {
            window.edughanaApp.modules.toast.show('Please fill in all fields', 'error');
            return;
        }

        // Show success message (no backend, so just simulate)
        window.edughanaApp.modules.toast.show('Thank you for your message! We\'ll get back to you soon.', 'success');
        form.reset();
    }

    // Missing notes functions
    showAddNoteModal() {
        const modalContent = `
            <form id="add-note-form" class="note-form">
                <div class="form-group">
                    <label for="note-title">Title</label>
                    <input type="text" id="note-title" name="title" class="form-input" required>
                </div>
                <div class="form-group">
                    <label for="note-subject">Subject</label>
                    <select id="note-subject" name="subject" class="form-input" required>
                        <option value="">Select Subject</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="English">English</option>
                        <option value="ICT">ICT</option>
                        <option value="Science">Science</option>
                        <option value="Social Studies">Social Studies</option>
                        <option value="Programming">Programming</option>
                        <option value="Business">Business</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="note-content">Content</label>
                    <textarea id="note-content" name="content" class="form-input" rows="6" required></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="this.closeAllModals()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Note</button>
                </div>
            </form>
        `;

        const modal = this.showModal(modalContent, 'Add New Note');
        
        // Add form submission handler
        const form = modal.querySelector('#add-note-form');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.submitAddNote(form);
        });
    }

    async submitAddNote(form) {
        const formData = new FormData(form);
        const noteData = {
            title: formData.get('title').trim(),
            subject: formData.get('subject'),
            content: formData.get('content').trim()
        };

        if (!noteData.title || !noteData.subject || !noteData.content) {
            window.edughanaApp.modules.toast.show('Please fill in all fields', 'error');
            return;
        }

        try {
            const result = await window.edughanaApp.modules.notes.createNote(
                this.currentUser.id,
                noteData.title,
                noteData.subject,
                noteData.content
            );

            if (result.success) {
                window.edughanaApp.modules.toast.show('Note created successfully!', 'success');
                this.closeAllModals();
                this.renderNotes();
                this.initNotesToolbar();
            } else {
                window.edughanaApp.modules.toast.show(result.error, 'error');
            }
        } catch (error) {
            window.edughanaApp.modules.toast.show('Failed to create note', 'error');
        }
    }

    editNote(noteId) {
        const note = window.edughanaApp.modules.notes.getNote(noteId);
        if (!note) return;

        const modalContent = `
            <form id="edit-note-form" class="note-form">
                <div class="form-group">
                    <label for="edit-note-title">Title</label>
                    <input type="text" id="edit-note-title" name="title" class="form-input" value="${note.title}" required>
                </div>
                <div class="form-group">
                    <label for="edit-note-subject">Subject</label>
                    <select id="edit-note-subject" name="subject" class="form-input" required>
                        <option value="Mathematics" ${note.subject === 'Mathematics' ? 'selected' : ''}>Mathematics</option>
                        <option value="English" ${note.subject === 'English' ? 'selected' : ''}>English</option>
                        <option value="ICT" ${note.subject === 'ICT' ? 'selected' : ''}>ICT</option>
                        <option value="Science" ${note.subject === 'Science' ? 'selected' : ''}>Science</option>
                        <option value="Social Studies" ${note.subject === 'Social Studies' ? 'selected' : ''}>Social Studies</option>
                        <option value="Programming" ${note.subject === 'Programming' ? 'selected' : ''}>Programming</option>
                        <option value="Business" ${note.subject === 'Business' ? 'selected' : ''}>Business</option>
                        <option value="Other" ${note.subject === 'Other' ? 'selected' : ''}>Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit-note-content">Content</label>
                    <textarea id="edit-note-content" name="content" class="form-input" rows="6" required>${note.content}</textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="this.closeAllModals()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Note</button>
                </div>
            </form>
        `;

        const modal = this.showModal(modalContent, 'Edit Note');
        
        // Add form submission handler
        const form = modal.querySelector('#edit-note-form');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.submitEditNote(form, noteId);
        });
    }

    async submitEditNote(form, noteId) {
        const formData = new FormData(form);
        const noteData = {
            title: formData.get('title').trim(),
            subject: formData.get('subject'),
            content: formData.get('content').trim()
        };

        if (!noteData.title || !noteData.subject || !noteData.content) {
            window.edughanaApp.modules.toast.show('Please fill in all fields', 'error');
            return;
        }

        try {
            const result = await window.edughanaApp.modules.notes.updateNote(
                noteId,
                noteData.title,
                noteData.subject,
                noteData.content
            );

            if (result.success) {
                window.edughanaApp.modules.toast.show('Note updated successfully!', 'success');
                this.closeAllModals();
                this.renderNotes();
            } else {
                window.edughanaApp.modules.toast.show(result.error, 'error');
            }
        } catch (error) {
            window.edughanaApp.modules.toast.show('Failed to update note', 'error');
        }
    }

    async deleteNote(noteId) {
        if (!confirm('Are you sure you want to delete this note? This action cannot be undone.')) {
            return;
        }

        try {
            const result = await window.edughanaApp.modules.notes.deleteNote(noteId);
            
            if (result.success) {
                window.edughanaApp.modules.toast.show('Note deleted successfully!', 'success');
                this.renderNotes();
            } else {
                window.edughanaApp.modules.toast.show(result.error, 'error');
            }
        } catch (error) {
            window.edughanaApp.modules.toast.show('Failed to delete note', 'error');
        }
    }

    searchNotes(query) {
        if (!query.trim()) {
            this.renderNotes();
            return;
        }

        const notes = window.edughanaApp.modules.notes.searchNotes(this.currentUser.id, query);
        this.renderFilteredNotes(notes);
    }

    filterNotesBySubject(subject) {
        if (subject === 'all') {
            this.renderNotes();
            return;
        }

        const notes = window.edughanaApp.modules.notes.filterNotesBySubject(this.currentUser.id, subject);
        this.renderFilteredNotes(notes);
    }

    sortNotes(sortBy) {
        const notes = window.edughanaApp.modules.notes.sortNotes(this.currentUser.id, sortBy);
        this.renderFilteredNotes(notes);
    }

    renderFilteredNotes(notes) {
        const notesGrid = document.querySelector('.notes-grid');
        if (!notesGrid) return;

        if (notes.length === 0) {
            notesGrid.innerHTML = `
                <div class="no-notes">
                    <h3>No Notes Found</h3>
                    <p>Try adjusting your search or filter criteria.</p>
                </div>
            `;
        } else {
            notesGrid.innerHTML = notes.map(note => `
                <div class="note-card" data-note-id="${note.id}">
                    <div class="note-header">
                        <h3 class="note-title">${note.title}</h3>
                        <span class="note-subject">${note.subject}</span>
                    </div>
                    <div class="note-content">
                        <p>${note.content.substring(0, 150)}${note.content.length > 150 ? '...' : ''}</p>
                    </div>
                    <div class="note-footer">
                        <span class="note-date">${new Date(note.updatedAt).toLocaleDateString()}</span>
                        <div class="note-actions">
                            <button class="btn btn-outline btn-sm" onclick="this.editNote('${note.id}')">Edit</button>
                            <button class="btn btn-outline btn-sm" onclick="this.deleteNote('${note.id}')">Delete</button>
                        </div>
                    </div>
                </div>
            `).join('');
        }
    }
}
