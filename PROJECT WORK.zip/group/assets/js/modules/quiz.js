// ===== QUIZ MODULE =====
// Handles quiz functionality, scoring, and persistence

export class QuizModule {
    constructor() {
        this.storageKey = 'edughana_quiz_scores';
        this.questions = this.getQuizQuestions();
        this.init();
    }

    init() {
        // Initialize quiz scores storage if it doesn't exist
        if (!localStorage.getItem(this.storageKey)) {
            localStorage.setItem(this.storageKey, JSON.stringify({}));
        }
    }

    // Get quiz questions for different courses
    getQuizQuestions() {
        return {
            'mathematics': [
                {
                    id: 'math_1',
                    question: 'What is the quadratic formula?',
                    options: [
                        'x = (-b ± √(b² - 4ac)) / 2a',
                        'x = (-b ± √(b² + 4ac)) / 2a',
                        'x = (b ± √(b² - 4ac)) / 2a',
                        'x = (-b ± √(b² - 4ac)) / a'
                    ],
                    correct: 0,
                    explanation: 'The quadratic formula is x = (-b ± √(b² - 4ac)) / 2a, used to solve quadratic equations in the form ax² + bx + c = 0.'
                },
                {
                    id: 'math_2',
                    question: 'What is the area of a circle with radius r?',
                    options: [
                        'πr',
                        '2πr',
                        'πr²',
                        '2πr²'
                    ],
                    correct: 2,
                    explanation: 'The area of a circle is πr², where r is the radius of the circle.'
                },
                {
                    id: 'math_3',
                    question: 'In a right-angled triangle, if a = 3 and b = 4, what is c?',
                    options: [
                        '5',
                        '6',
                        '7',
                        '8'
                    ],
                    correct: 0,
                    explanation: 'Using Pythagoras theorem: c² = a² + b² = 3² + 4² = 9 + 16 = 25, so c = √25 = 5.'
                },
                {
                    id: 'math_4',
                    question: 'What is the value of sin(30°)?',
                    options: [
                        '0.5',
                        '0.707',
                        '0.866',
                        '1'
                    ],
                    correct: 0,
                    explanation: 'sin(30°) = 0.5, which is a standard trigonometric value.'
                },
                {
                    id: 'math_5',
                    question: 'What is the volume of a cylinder with radius r and height h?',
                    options: [
                        'πrh',
                        '2πrh',
                        'πr²h',
                        '2πr²h'
                    ],
                    correct: 2,
                    explanation: 'The volume of a cylinder is πr²h, where r is the radius and h is the height.'
                }
            ],
            'ict': [
                {
                    id: 'ict_1',
                    question: 'What is a variable in programming?',
                    options: [
                        'A fixed value that cannot change',
                        'A container that stores data values',
                        'A type of function',
                        'A programming language'
                    ],
                    correct: 1,
                    explanation: 'A variable is a container that stores data values and can be changed during program execution.'
                },
                {
                    id: 'ict_2',
                    question: 'Which loop structure repeats code while a condition is true?',
                    options: [
                        'if statement',
                        'while loop',
                        'switch statement',
                        'function call'
                    ],
                    correct: 1,
                    explanation: 'A while loop repeats code while a specified condition remains true.'
                },
                {
                    id: 'ict_3',
                    question: 'What is an array in programming?',
                    options: [
                        'A single variable',
                        'A collection of elements stored at contiguous memory locations',
                        'A type of function',
                        'A programming language'
                    ],
                    correct: 1,
                    explanation: 'An array is a collection of elements stored at contiguous memory locations, accessible by index.'
                },
                {
                    id: 'ict_4',
                    question: 'What does OOP stand for in programming?',
                    options: [
                        'Object-Oriented Programming',
                        'Online Object Processing',
                        'Object Output Protocol',
                        'Organized Object Programming'
                    ],
                    correct: 0,
                    explanation: 'OOP stands for Object-Oriented Programming, a programming paradigm based on objects.'
                },
                {
                    id: 'ict_5',
                    question: 'What is a function in programming?',
                    options: [
                        'A variable',
                        'A reusable block of code that performs a specific task',
                        'A data type',
                        'A programming language'
                    ],
                    correct: 1,
                    explanation: 'A function is a reusable block of code that performs a specific task when called.'
                }
            ]
        };
    }

    // Get questions for a specific course
    getCourseQuestions(courseId) {
        return this.questions[courseId] || [];
    }

    // Get all available courses
    getAvailableCourses() {
        return Object.keys(this.questions);
    }

    // Start a new quiz
    startQuiz(courseId) {
        const questions = this.getCourseQuestions(courseId);
        if (questions.length === 0) {
            throw new Error('No questions available for this course');
        }

        const quizState = {
            courseId: courseId,
            questions: questions,
            currentQuestion: 0,
            answers: new Array(questions.length).fill(null),
            startTime: Date.now(),
            timeLimit: 10 * 60 * 1000, // 10 minutes
            isCompleted: false
        };

        return quizState;
    }

    // Get current question
    getCurrentQuestion(quizState) {
        if (!quizState || quizState.currentQuestion >= quizState.questions.length) {
            return null;
        }
        return quizState.questions[quizState.currentQuestion];
    }

    // Answer current question
    answerQuestion(quizState, answerIndex) {
        if (!quizState || quizState.isCompleted) {
            return false;
        }

        const currentQuestion = this.getCurrentQuestion(quizState);
        if (!currentQuestion) {
            return false;
        }

        // Validate answer index
        if (answerIndex < 0 || answerIndex >= currentQuestion.options.length) {
            return false;
        }

        // Record answer
        quizState.answers[quizState.currentQuestion] = answerIndex;

        return true;
    }

    // Move to next question
    nextQuestion(quizState) {
        if (!quizState || quizState.isCompleted) {
            return false;
        }

        if (quizState.currentQuestion < quizState.questions.length - 1) {
            quizState.currentQuestion++;
            return true;
        }

        return false;
    }

    // Move to previous question
    previousQuestion(quizState) {
        if (!quizState || quizState.isCompleted) {
            return false;
        }

        if (quizState.currentQuestion > 0) {
            quizState.currentQuestion--;
            return true;
        }

        return false;
    }

    // Submit quiz and calculate score
    submitQuiz(quizState) {
        if (!quizState || quizState.isCompleted) {
            return null;
        }

        const questions = quizState.questions;
        const answers = quizState.answers;
        let correctAnswers = 0;
        let totalQuestions = questions.length;

        // Calculate score
        for (let i = 0; i < totalQuestions; i++) {
            if (answers[i] !== null && answers[i] === questions[i].correct) {
                correctAnswers++;
            }
        }

        const score = Math.round((correctAnswers / totalQuestions) * 100);
        const timeTaken = Date.now() - quizState.startTime;

        // Mark quiz as completed
        quizState.isCompleted = true;
        quizState.endTime = Date.now();
        quizState.score = score;
        quizState.correctAnswers = correctAnswers;
        quizState.totalQuestions = totalQuestions;
        quizState.timeTaken = timeTaken;

        return {
            score: score,
            correctAnswers: correctAnswers,
            totalQuestions: totalQuestions,
            timeTaken: timeTaken,
            answers: answers,
            questions: questions
        };
    }

    // Get quiz progress
    getQuizProgress(quizState) {
        if (!quizState) {
            return { current: 0, total: 0, percentage: 0 };
        }

        const current = quizState.currentQuestion + 1;
        const total = quizState.questions.length;
        const percentage = Math.round((current / total) * 100);

        return { current, total, percentage };
    }

    // Get remaining time
    getRemainingTime(quizState) {
        if (!quizState || quizState.isCompleted) {
            return 0;
        }

        const elapsed = Date.now() - quizState.startTime;
        const remaining = Math.max(0, quizState.timeLimit - elapsed);

        return remaining;
    }

    // Check if quiz time is up
    isTimeUp(quizState) {
        return this.getRemainingTime(quizState) <= 0;
    }

    // Format time in MM:SS format
    formatTime(milliseconds) {
        const totalSeconds = Math.floor(milliseconds / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    // Save quiz score for a user
    saveQuizScore(userId, courseId, quizResult) {
        try {
            const scores = this.getUserScores(userId);
            
            if (!scores[courseId]) {
                scores[courseId] = [];
            }

            const scoreRecord = {
                id: 'score_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                courseId: courseId,
                score: quizResult.score,
                correctAnswers: quizResult.correctAnswers,
                totalQuestions: quizResult.totalQuestions,
                timeTaken: quizResult.timeTaken,
                completedAt: new Date().toISOString()
            };

            scores[courseId].push(scoreRecord);
            this.saveUserScores(userId, scores);

            return { success: true, scoreRecord: scoreRecord };
        } catch (error) {
            console.error('Error saving quiz score:', error);
            return { success: false, error: error.message };
        }
    }

    // Get all quiz scores for a user
    getUserScores(userId) {
        try {
            const scores = localStorage.getItem(this.storageKey);
            const allScores = scores ? JSON.parse(scores) : {};
            return allScores[userId] || {};
        } catch (error) {
            console.error('Error reading quiz scores:', error);
            return {};
        }
    }

    // Save quiz scores for a user
    saveUserScores(userId, scores) {
        try {
            const allScores = localStorage.getItem(this.storageKey);
            const parsedScores = allScores ? JSON.parse(allScores) : {};
            parsedScores[userId] = scores;
            localStorage.setItem(this.storageKey, JSON.stringify(parsedScores));
        } catch (error) {
            console.error('Error saving quiz scores:', error);
            throw new Error('Failed to save quiz scores');
        }
    }

    // Get best score for a specific course
    getBestScore(userId, courseId) {
        try {
            const scores = this.getUserScores(userId);
            const courseScores = scores[courseId] || [];
            
            if (courseScores.length === 0) {
                return null;
            }

            // Return the highest score
            return courseScores.reduce((best, current) => 
                current.score > best.score ? current : best
            );
        } catch (error) {
            console.error('Error getting best score:', error);
            return null;
        }
    }

    // Get quiz statistics for a user
    getUserQuizStats(userId) {
        try {
            const scores = this.getUserScores(userId);
            const allScores = Object.values(scores).flat();
            
            if (allScores.length === 0) {
                return {
                    totalQuizzes: 0,
                    averageScore: 0,
                    bestScore: 0,
                    totalTime: 0,
                    coursesTaken: 0
                };
            }

            const totalQuizzes = allScores.length;
            const totalScore = allScores.reduce((sum, score) => sum + score.score, 0);
            const averageScore = Math.round(totalScore / totalQuizzes);
            const bestScore = Math.max(...allScores.map(score => score.score));
            const totalTime = allScores.reduce((sum, score) => sum + score.timeTaken, 0);
            const coursesTaken = Object.keys(scores).length;

            return {
                totalQuizzes,
                averageScore,
                bestScore,
                totalTime,
                coursesTaken
            };
        } catch (error) {
            console.error('Error getting quiz stats:', error);
            return {
                totalQuizzes: 0,
                averageScore: 0,
                bestScore: 0,
                totalTime: 0,
                coursesTaken: 0
            };
        }
    }

    // Get course-specific statistics
    getCourseStats(userId, courseId) {
        try {
            const scores = this.getUserScores(userId);
            const courseScores = scores[courseId] || [];
            
            if (courseScores.length === 0) {
                return {
                    attempts: 0,
                    bestScore: 0,
                    averageScore: 0,
                    lastAttempt: null
                };
            }

            const attempts = courseScores.length;
            const bestScore = Math.max(...courseScores.map(score => score.score));
            const totalScore = courseScores.reduce((sum, score) => sum + score.score, 0);
            const averageScore = Math.round(totalScore / attempts);
            const lastAttempt = courseScores[courseScores.length - 1].completedAt;

            return {
                attempts,
                bestScore,
                averageScore,
                lastAttempt
            };
        } catch (error) {
            console.error('Error getting course stats:', error);
            return {
                attempts: 0,
                bestScore: 0,
                averageScore: 0,
                lastAttempt: null
            };
        }
    }

    // Reset quiz progress (for retaking)
    resetQuiz(quizState) {
        if (!quizState) {
            return null;
        }

        return {
            ...quizState,
            currentQuestion: 0,
            answers: new Array(quizState.questions.length).fill(null),
            startTime: Date.now(),
            isCompleted: false
        };
    }

    // Get quiz review (showing correct answers and explanations)
    getQuizReview(quizResult) {
        if (!quizResult || !quizResult.questions || !quizResult.answers) {
            return null;
        }

        const review = quizResult.questions.map((question, index) => {
            const userAnswer = quizResult.answers[index];
            const isCorrect = userAnswer === question.correct;
            
            return {
                question: question.question,
                userAnswer: userAnswer !== null ? question.options[userAnswer] : 'Not answered',
                correctAnswer: question.options[question.correct],
                isCorrect: isCorrect,
                explanation: question.explanation
            };
        });

        return review;
    }

    // Export quiz data for backup
    exportQuizData(userId) {
        try {
            const scores = this.getUserScores(userId);
            const exportData = {
                exportDate: new Date().toISOString(),
                userId: userId,
                quizScores: scores
            };

            return JSON.stringify(exportData, null, 2);
        } catch (error) {
            console.error('Error exporting quiz data:', error);
            return null;
        }
    }

    // Import quiz data from backup
    async importQuizData(userId, importData) {
        try {
            const parsedData = JSON.parse(importData);
            
            if (!parsedData.quizScores) {
                throw new Error('Invalid import data format');
            }

            const existingScores = this.getUserScores(userId);
            const importedScores = parsedData.quizScores;
            
            // Merge imported scores with existing ones
            const mergedScores = { ...existingScores };
            
            for (const [courseId, courseScores] of Object.entries(importedScores)) {
                if (!mergedScores[courseId]) {
                    mergedScores[courseId] = [];
                }
                
                // Add imported scores with new IDs
                const importedCourseScores = courseScores.map(score => ({
                    ...score,
                    id: 'score_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9)
                }));
                
                mergedScores[courseId].push(...importedCourseScores);
            }

            this.saveUserScores(userId, mergedScores);

            return {
                success: true,
                importedCourses: Object.keys(importedScores).length
            };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }
}
