// ===== RESOURCES MODULE =====
// Handles fetching learning resources from external APIs

export class ResourcesModule {
    constructor() {
        this.openLibraryBaseUrl = 'https://openlibrary.org';
        this.wikipediaBaseUrl = 'https://en.wikipedia.org/api/rest_v1';
        this.cache = new Map();
        this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    }

    // Search for resources using multiple APIs
    async searchResources(query, limit = 5) {
        try {
            if (!query || query.trim().length < 2) {
                throw new Error('Search query must be at least 2 characters long');
            }

            const searchTerm = query.trim();
            const results = [];

            // Try Open Library first
            try {
                const openLibraryResults = await this.searchOpenLibrary(searchTerm, limit);
                results.push(...openLibraryResults);
            } catch (error) {
                console.log('Open Library search failed:', error);
            }

            // If we don't have enough results, try Wikipedia
            if (results.length < limit) {
                try {
                    const wikipediaResults = await this.searchWikipedia(searchTerm, limit - results.length);
                    results.push(...wikipediaResults);
                } catch (error) {
                    console.log('Wikipedia search failed:', error);
                }
            }

            // Remove duplicates and limit results
            const uniqueResults = this.removeDuplicates(results);
            return uniqueResults.slice(0, limit);

        } catch (error) {
            console.error('Resource search failed:', error);
            throw error;
        }
    }

    // Search Open Library API
    async searchOpenLibrary(query, limit = 5) {
        try {
            const cacheKey = `openlibrary_${query}`;
            const cached = this.getCachedResult(cacheKey);
            if (cached) return cached;

            const searchUrl = `${this.openLibraryBaseUrl}/search.json?q=${encodeURIComponent(query)}&limit=${limit}`;
            const response = await fetch(searchUrl);
            
            if (!response.ok) {
                throw new Error(`Open Library API error: ${response.status}`);
            }

            const data = await response.json();
            const results = [];

            if (data.docs && Array.isArray(data.docs)) {
                for (const doc of data.docs) {
                    if (results.length >= limit) break;

                    const result = {
                        title: doc.title || 'Untitled',
                        snippet: this.generateOpenLibrarySnippet(doc),
                        link: doc.key ? `${this.openLibraryBaseUrl}${doc.key}` : null,
                        source: 'Open Library',
                        type: 'book',
                        author: doc.author_name ? doc.author_name.join(', ') : 'Unknown Author',
                        year: doc.first_publish_year || 'Unknown Year'
                    };

                    if (result.link) {
                        results.push(result);
                    }
                }
            }

            this.cacheResult(cacheKey, results);
            return results;

        } catch (error) {
            console.error('Open Library search error:', error);
            throw new Error('Failed to search Open Library');
        }
    }

    // Search Wikipedia API
    async searchWikipedia(query, limit = 5) {
        try {
            const cacheKey = `wikipedia_${query}`;
            const cached = this.getCachedResult(cacheKey);
            if (cached) return cached;

            const searchUrl = `${this.wikipediaBaseUrl}/page/summary/${encodeURIComponent(query)}`;
            const response = await fetch(searchUrl);
            
            if (!response.ok) {
                throw new Error(`Wikipedia API error: ${response.status}`);
            }

            const data = await response.json();
            const results = [];

            if (data.title && data.extract) {
                const result = {
                    title: data.title,
                    snippet: this.truncateText(data.extract, 200),
                    link: data.content_urls?.desktop?.page || null,
                    source: 'Wikipedia',
                    type: 'article',
                    author: 'Wikipedia Contributors',
                    year: new Date().getFullYear().toString()
                };

                if (result.link) {
                    results.push(result);
                }
            }

            // If single page search didn't work, try search API
            if (results.length === 0) {
                const searchResults = await this.searchWikipediaPages(query, limit);
                results.push(...searchResults);
            }

            this.cacheResult(cacheKey, results);
            return results;

        } catch (error) {
            console.error('Wikipedia search error:', error);
            throw new Error('Failed to search Wikipedia');
        }
    }

    // Search Wikipedia pages using search API
    async searchWikipediaPages(query, limit = 5) {
        try {
            const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&origin=*&srlimit=${limit}`;
            const response = await fetch(searchUrl);
            
            if (!response.ok) {
                throw new Error(`Wikipedia search API error: ${response.status}`);
            }

            const data = await response.json();
            const results = [];

            if (data.query && data.query.search && Array.isArray(data.query.search)) {
                for (const item of data.query.search) {
                    if (results.length >= limit) break;

                    const result = {
                        title: item.title,
                        snippet: this.stripHtmlTags(item.snippet),
                        link: `https://en.wikipedia.org/wiki/${encodeURIComponent(item.title)}`,
                        source: 'Wikipedia',
                        type: 'article',
                        author: 'Wikipedia Contributors',
                        year: new Date().getFullYear().toString()
                    };

                    results.push(result);
                }
            }

            return results;

        } catch (error) {
            console.error('Wikipedia pages search error:', error);
            return [];
        }
    }

    // Generate snippet from Open Library data
    generateOpenLibrarySnippet(doc) {
        let snippet = '';

        if (doc.subtitle) {
            snippet += doc.subtitle + '. ';
        }

        if (doc.author_name && doc.author_name.length > 0) {
            snippet += `By ${doc.author_name.join(', ')}. `;
        }

        if (doc.first_publish_year) {
            snippet += `Published in ${doc.first_publish_year}. `;
        }

        if (doc.subject && doc.subject.length > 0) {
            snippet += `Subjects: ${doc.subject.slice(0, 3).join(', ')}.`;
        }

        if (!snippet.trim()) {
            snippet = 'Educational resource from Open Library.';
        }

        return this.truncateText(snippet, 200);
    }

    // Strip HTML tags from text
    stripHtmlTags(html) {
        if (!html) return '';
        return html.replace(/<[^>]*>/g, '');
    }

    // Truncate text to specified length
    truncateText(text, maxLength) {
        if (!text || text.length <= maxLength) return text;
        return text.substring(0, maxLength).trim() + '...';
    }

    // Remove duplicate results
    removeDuplicates(results) {
        const seen = new Set();
        return results.filter(result => {
            const key = `${result.title}-${result.source}`;
            if (seen.has(key)) {
                return false;
            }
            seen.add(key);
            return true;
        });
    }

    // Cache management
    getCachedResult(key) {
        const cached = this.cache.get(key);
        if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
            return cached.data;
        }
        this.cache.delete(key);
        return null;
    }

    cacheResult(key, data) {
        this.cache.set(key, {
            data: data,
            timestamp: Date.now()
        });
    }

    // Clear cache
    clearCache() {
        this.cache.clear();
    }

    // Get cache statistics
    getCacheStats() {
        const now = Date.now();
        const validEntries = Array.from(this.cache.entries()).filter(([key, value]) => 
            now - value.timestamp < this.cacheTimeout
        );

        return {
            totalEntries: this.cache.size,
            validEntries: validEntries.length,
            expiredEntries: this.cache.size - validEntries.length
        };
    }

    // Search with fallback strategy
    async searchWithFallback(query, limit = 5) {
        const results = [];
        let error = null;

        // Try Open Library first
        try {
            const openLibraryResults = await this.searchOpenLibrary(query, limit);
            results.push(...openLibraryResults);
        } catch (err) {
            error = err;
            console.log('Open Library fallback failed:', err);
        }

        // If no results, try Wikipedia
        if (results.length === 0) {
            try {
                const wikipediaResults = await this.searchWikipedia(query, limit);
                results.push(...wikipediaResults);
            } catch (err) {
                error = err;
                console.log('Wikipedia fallback failed:', err);
            }
        }

        // If still no results, return error
        if (results.length === 0 && error) {
            throw error;
        }

        return results.slice(0, limit);
    }

    // Get trending educational topics (mock data for Ghana context)
    getTrendingTopics() {
        return [
            'WASSCE Mathematics',
            'Ghana History',
            'Python Programming',
            'Photosynthesis',
            'Kwame Nkrumah',
            'Data Structures',
            'English Literature',
            'Computer Science',
            'Ghana Geography',
            'Programming Fundamentals'
        ];
    }

    // Get subject-specific resources
    async getSubjectResources(subject, limit = 5) {
        const subjectQueries = {
            'mathematics': ['algebra', 'geometry', 'calculus', 'statistics'],
            'english': ['literature', 'grammar', 'writing', 'poetry'],
            'science': ['physics', 'chemistry', 'biology', 'experiments'],
            'ict': ['programming', 'computer science', 'web development', 'databases'],
            'social studies': ['ghana history', 'geography', 'economics', 'government']
        };

        const queries = subjectQueries[subject.toLowerCase()] || [subject];
        const allResults = [];

        for (const query of queries) {
            try {
                const results = await this.searchResources(query, Math.ceil(limit / queries.length));
                allResults.push(...results);
            } catch (error) {
                console.log(`Failed to search for ${query}:`, error);
            }
        }

        // Remove duplicates and limit results
        const uniqueResults = this.removeDuplicates(allResults);
        return uniqueResults.slice(0, limit);
    }

    // Validate search query
    validateQuery(query) {
        if (!query || typeof query !== 'string') {
            return { valid: false, error: 'Query must be a string' };
        }

        const trimmed = query.trim();
        if (trimmed.length < 2) {
            return { valid: false, error: 'Query must be at least 2 characters long' };
        }

        if (trimmed.length > 100) {
            return { valid: false, error: 'Query must be less than 100 characters' };
        }

        // Check for potentially harmful content
        const harmfulPatterns = /<script|javascript:|data:|vbscript:/i;
        if (harmfulPatterns.test(trimmed)) {
            return { valid: false, error: 'Query contains invalid characters' };
        }

        return { valid: true, query: trimmed };
    }

    // Rate limiting (simple implementation)
    constructor() {
        this.requestCount = 0;
        this.lastReset = Date.now();
        this.maxRequestsPerMinute = 30;
    }

    checkRateLimit() {
        const now = Date.now();
        if (now - this.lastReset >= 60000) { // 1 minute
            this.requestCount = 0;
            this.lastReset = now;
        }

        if (this.requestCount >= this.maxRequestsPerMinute) {
            throw new Error('Rate limit exceeded. Please try again later.');
        }

        this.requestCount++;
        return true;
    }

    // Enhanced search with rate limiting
    async searchResourcesWithRateLimit(query, limit = 5) {
        try {
            this.checkRateLimit();
            return await this.searchResources(query, limit);
        } catch (error) {
            if (error.message.includes('Rate limit')) {
                throw error;
            }
            throw new Error('Search failed. Please try again later.');
        }
    }
}
