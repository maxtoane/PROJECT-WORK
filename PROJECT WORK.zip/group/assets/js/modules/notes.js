// ===== NOTES MODULE =====
// Handles CRUD operations for user study notes

export class NotesModule {
    constructor() {
        this.storageKey = 'edughana_notes';
        this.init();
    }

    init() {
        // Initialize notes storage if it doesn't exist
        if (!localStorage.getItem(this.storageKey)) {
            localStorage.setItem(this.storageKey, JSON.stringify({}));
        }
    }

    // Generate unique note ID
    generateNoteId() {
        return 'note_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Get all notes from localStorage
    getNotes() {
        try {
            const notes = localStorage.getItem(this.storageKey);
            return notes ? JSON.parse(notes) : {};
        } catch (error) {
            console.error('Error reading notes from localStorage:', error);
            return {};
        }
    }

    // Save notes to localStorage
    saveNotes(notes) {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(notes));
        } catch (error) {
            console.error('Error saving notes to localStorage:', error);
            throw new Error('Failed to save notes');
        }
    }

    // Get notes for a specific user
    getUserNotes(userId) {
        try {
            const notes = this.getNotes();
            const userNotes = notes[userId] || [];
            
            // Sort by most recent first
            return userNotes.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
        } catch (error) {
            console.error('Error getting user notes:', error);
            return [];
        }
    }

    // Create a new note
    async createNote(userId, noteData) {
        try {
            const { title, subject, content } = noteData;

            // Validation
            if (!title || !subject || !content) {
                throw new Error('Title, subject, and content are required');
            }

            if (title.trim().length < 3) {
                throw new Error('Title must be at least 3 characters long');
            }

            if (content.trim().length < 10) {
                throw new Error('Content must be at least 10 characters long');
            }

            // Create note object
            const note = {
                id: this.generateNoteId(),
                title: title.trim(),
                subject: subject.trim(),
                content: content.trim(),
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };

            // Save note
            const notes = this.getNotes();
            if (!notes[userId]) {
                notes[userId] = [];
            }
            
            notes[userId].push(note);
            this.saveNotes(notes);

            return {
                success: true,
                note: note
            };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Get a specific note by ID
    getNote(userId, noteId) {
        try {
            const notes = this.getNotes();
            const userNotes = notes[userId] || [];
            return userNotes.find(note => note.id === noteId) || null;
        } catch (error) {
            console.error('Error getting note:', error);
            return null;
        }
    }

    // Update an existing note
    async updateNote(userId, noteId, updates) {
        try {
            const notes = this.getNotes();
            const userNotes = notes[userId] || [];
            const noteIndex = userNotes.findIndex(note => note.id === noteId);

            if (noteIndex === -1) {
                throw new Error('Note not found');
            }

            const note = userNotes[noteIndex];

            // Validation
            if (updates.title && updates.title.trim().length < 3) {
                throw new Error('Title must be at least 3 characters long');
            }

            if (updates.content && updates.content.trim().length < 10) {
                throw new Error('Content must be at least 10 characters long');
            }

            // Apply updates
            if (updates.title) note.title = updates.title.trim();
            if (updates.subject) note.subject = updates.subject.trim();
            if (updates.content) note.content = updates.content.trim();
            
            note.updatedAt = new Date().toISOString();

            // Save updated notes
            userNotes[noteIndex] = note;
            notes[userId] = userNotes;
            this.saveNotes(notes);

            return {
                success: true,
                note: note
            };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Delete a note
    async deleteNote(userId, noteId) {
        try {
            const notes = this.getNotes();
            const userNotes = notes[userId] || [];
            const noteIndex = userNotes.findIndex(note => note.id === noteId);

            if (noteIndex === -1) {
                throw new Error('Note not found');
            }

            // Remove note
            userNotes.splice(noteIndex, 1);
            notes[userId] = userNotes;
            this.saveNotes(notes);

            return { success: true };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Search notes by keyword
    searchNotes(userId, query) {
        try {
            const userNotes = this.getUserNotes(userId);
            const searchTerm = query.toLowerCase().trim();

            if (!searchTerm) {
                return userNotes;
            }

            return userNotes.filter(note => 
                note.title.toLowerCase().includes(searchTerm) ||
                note.subject.toLowerCase().includes(searchTerm) ||
                note.content.toLowerCase().includes(searchTerm)
            );
        } catch (error) {
            console.error('Error searching notes:', error);
            return [];
        }
    }

    // Filter notes by subject
    filterNotesBySubject(userId, subject) {
        try {
            const userNotes = this.getUserNotes(userId);
            
            if (!subject || subject === 'all') {
                return userNotes;
            }

            return userNotes.filter(note => 
                note.subject.toLowerCase() === subject.toLowerCase()
            );
        } catch (error) {
            console.error('Error filtering notes by subject:', error);
            return [];
        }
    }

    // Get unique subjects for a user
    getUserSubjects(userId) {
        try {
            const userNotes = this.getUserNotes(userId);
            const subjects = [...new Set(userNotes.map(note => note.subject))];
            return subjects.sort();
        } catch (error) {
            console.error('Error getting user subjects:', error);
            return [];
        }
    }

    // Sort notes by different criteria
    sortNotes(notes, sortBy = 'newest') {
        try {
            const sortedNotes = [...notes];

            switch (sortBy) {
                case 'newest':
                    return sortedNotes.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
                
                case 'oldest':
                    return sortedNotes.sort((a, b) => new Date(a.updatedAt) - new Date(b.updatedAt));
                
                case 'title':
                    return sortedNotes.sort((a, b) => a.title.localeCompare(b.title));
                
                case 'subject':
                    return sortedNotes.sort((a, b) => a.subject.localeCompare(b.subject));
                
                default:
                    return sortedNotes;
            }
        } catch (error) {
            console.error('Error sorting notes:', error);
            return notes;
        }
    }

    // Get note statistics for a user
    getUserNoteStats(userId) {
        try {
            const userNotes = this.getUserNotes(userId);
            const subjects = this.getUserSubjects(userId);
            
            const stats = {
                totalNotes: userNotes.length,
                totalSubjects: subjects.length,
                recentNotes: userNotes.filter(note => {
                    const noteDate = new Date(note.updatedAt);
                    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    return noteDate > weekAgo;
                }).length,
                subjects: subjects.map(subject => ({
                    name: subject,
                    count: userNotes.filter(note => note.subject === subject).length
                }))
            };

            return stats;
        } catch (error) {
            console.error('Error getting note stats:', error);
            return {
                totalNotes: 0,
                totalSubjects: 0,
                recentNotes: 0,
                subjects: []
            };
        }
    }

    // Export notes for a user (for backup purposes)
    exportUserNotes(userId) {
        try {
            const userNotes = this.getUserNotes(userId);
            const exportData = {
                exportDate: new Date().toISOString(),
                userId: userId,
                notes: userNotes
            };

            return JSON.stringify(exportData, null, 2);
        } catch (error) {
            console.error('Error exporting notes:', error);
            return null;
        }
    }

    // Import notes for a user (for restore purposes)
    async importUserNotes(userId, importData) {
        try {
            const parsedData = JSON.parse(importData);
            
            if (!parsedData.notes || !Array.isArray(parsedData.notes)) {
                throw new Error('Invalid import data format');
            }

            const notes = this.getNotes();
            const existingNotes = notes[userId] || [];
            
            // Add imported notes with new IDs
            const importedNotes = parsedData.notes.map(note => ({
                ...note,
                id: this.generateNoteId(),
                createdAt: note.createdAt || new Date().toISOString(),
                updatedAt: note.updatedAt || new Date().toISOString()
            }));

            notes[userId] = [...existingNotes, ...importedNotes];
            this.saveNotes(notes);

            return {
                success: true,
                importedCount: importedNotes.length
            };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Seed demo notes for testing
    seedDemoNotes(userId) {
        try {
            const demoNotes = [
                {
                    id: this.generateNoteId(),
                    title: 'WASSCE Mathematics Tips',
                    subject: 'Mathematics',
                    content: 'Key formulas to remember for WASSCE Mathematics: Quadratic formula, Area of circle, Volume of cylinder, Pythagoras theorem, and Trigonometric ratios.',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                },
                {
                    id: this.generateNoteId(),
                    title: 'English Literature Notes',
                    subject: 'English',
                    content: 'Important literary devices: Metaphor, Simile, Personification, Alliteration, and Irony. Remember to analyze themes and character development.',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                },
                {
                    id: this.generateNoteId(),
                    title: 'ICT Programming Basics',
                    subject: 'ICT',
                    content: 'Programming fundamentals: Variables, Loops, Functions, Arrays, and Object-Oriented Programming concepts. Practice with simple algorithms.',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                }
            ];

            const notes = this.getNotes();
            if (!notes[userId]) {
                notes[userId] = [];
            }
            
            notes[userId].push(...demoNotes);
            this.saveNotes(notes);

            console.log('Demo notes seeded successfully');
            return true;
        } catch (error) {
            console.error('Failed to seed demo notes:', error);
            return false;
        }
    }

    // Clean up old notes (optional maintenance function)
    cleanupOldNotes(userId, daysOld = 365) {
        try {
            const notes = this.getNotes();
            const userNotes = notes[userId] || [];
            const cutoffDate = new Date(Date.now() - daysOld * 24 * 60 * 60 * 1000);
            
            const activeNotes = userNotes.filter(note => 
                new Date(note.updatedAt) > cutoffDate
            );

            if (activeNotes.length < userNotes.length) {
                notes[userId] = activeNotes;
                this.saveNotes(notes);
                console.log(`Cleaned up ${userNotes.length - activeNotes.length} old notes`);
            }

            return true;
        } catch (error) {
            console.error('Error cleaning up old notes:', error);
            return false;
        }
    }
}
