// ===== TOAST NOTIFICATION MODULE =====
// Handles displaying toast notifications to users

export class ToastModule {
    constructor() {
        this.container = null;
        this.toasts = new Map();
        this.nextId = 1;
        this.init();
    }

    init() {
        // Find or create toast container
        this.container = document.getElementById('toast-container');
        if (!this.container) {
            this.container = this.createContainer();
        }
    }

    // Create toast container if it doesn't exist
    createContainer() {
        const container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
        return container;
    }

    // Show a toast notification
    show(message, type = 'info', duration = 5000) {
        if (!this.container) {
            this.init();
        }

        const toast = this.createToast(message, type);
        this.container.appendChild(toast);

        // Add to tracking
        const toastId = this.nextId++;
        this.toasts.set(toastId, toast);

        // Auto-remove after duration
        if (duration > 0) {
            setTimeout(() => {
                this.remove(toastId);
            }, duration);
        }

        // Add entrance animation
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });

        return toastId;
    }

    // Show success toast
    success(message, duration = 5000) {
        return this.show(message, 'success', duration);
    }

    // Show error toast
    error(message, duration = 7000) {
        return this.show(message, 'error', duration);
    }

    // Show warning toast
    warning(message, duration = 6000) {
        return this.show(message, 'warning', duration);
    }

    // Show info toast
    info(message, duration = 5000) {
        return this.show(message, 'info', duration);
    }

    // Create toast element
    createToast(message, type) {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        // Create toast content
        const content = document.createElement('div');
        content.className = 'toast-content';
        
        // Add icon based on type
        const icon = this.getToastIcon(type);
        if (icon) {
            const iconElement = document.createElement('span');
            iconElement.className = 'toast-icon';
            iconElement.textContent = icon;
            content.appendChild(iconElement);
        }
        
        // Add message
        const messageElement = document.createElement('span');
        messageElement.className = 'toast-message';
        messageElement.textContent = message;
        content.appendChild(messageElement);
        
        // Add close button
        const closeButton = document.createElement('button');
        closeButton.className = 'toast-close';
        closeButton.innerHTML = '&times;';
        closeButton.setAttribute('aria-label', 'Close notification');
        closeButton.addEventListener('click', () => {
            this.removeToast(toast);
        });
        
        toast.appendChild(content);
        toast.appendChild(closeButton);
        
        // Add click to dismiss functionality
        toast.addEventListener('click', (e) => {
            if (e.target !== closeButton) {
                this.removeToast(toast);
            }
        });
        
        return toast;
    }

    // Get appropriate icon for toast type
    getToastIcon(type) {
        const icons = {
            success: '✓',
            error: '✕',
            warning: '⚠',
            info: 'ℹ'
        };
        return icons[type] || '';
    }

    // Remove toast by ID
    remove(toastId) {
        const toast = this.toasts.get(toastId);
        if (toast) {
            this.removeToast(toast);
            this.toasts.delete(toastId);
        }
    }

    // Remove toast element
    removeToast(toast) {
        if (!toast || !toast.parentNode) return;
        
        // Add exit animation
        toast.classList.add('hiding');
        
        // Remove after animation
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }

    // Remove all toasts
    clear() {
        this.toasts.forEach((toast, id) => {
            this.remove(id);
        });
    }

    // Remove toasts by type
    clearByType(type) {
        this.toasts.forEach((toast, id) => {
            if (toast.classList.contains(type)) {
                this.remove(id);
            }
        });
    }

    // Get toast count
    getCount() {
        return this.toasts.size;
    }

    // Get toast count by type
    getCountByType(type) {
        let count = 0;
        this.toasts.forEach((toast) => {
            if (toast.classList.contains(type)) {
                count++;
            }
        });
        return count;
    }

    // Show multiple toasts
    showMultiple(messages, type = 'info', duration = 5000) {
        const ids = [];
        messages.forEach((message, index) => {
            // Stagger toasts slightly
            setTimeout(() => {
                const id = this.show(message, type, duration);
                ids.push(id);
            }, index * 100);
        });
        return ids;
    }

    // Show toast with custom HTML content
    showHTML(html, type = 'info', duration = 5000) {
        if (!this.container) {
            this.init();
        }

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const content = document.createElement('div');
        content.className = 'toast-content';
        content.innerHTML = html;
        
        const closeButton = document.createElement('button');
        closeButton.className = 'toast-close';
        closeButton.innerHTML = '&times;';
        closeButton.setAttribute('aria-label', 'Close notification');
        closeButton.addEventListener('click', () => {
            this.removeToast(toast);
        });
        
        toast.appendChild(content);
        toast.appendChild(closeButton);
        
        this.container.appendChild(toast);
        
        // Add entrance animation
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });
        
        // Auto-remove after duration
        if (duration > 0) {
            setTimeout(() => {
                this.removeToast(toast);
            }, duration);
        }
        
        return toast;
    }

    // Show toast with action buttons
    showWithActions(message, actions, type = 'info', duration = 0) {
        if (!this.container) {
            this.init();
        }

        const toast = document.createElement('div');
        toast.className = `toast ${type} toast-with-actions`;
        
        const content = document.createElement('div');
        content.className = 'toast-content';
        
        const messageElement = document.createElement('span');
        messageElement.className = 'toast-message';
        messageElement.textContent = message;
        content.appendChild(messageElement);
        
        // Add action buttons
        if (actions && actions.length > 0) {
            const actionsContainer = document.createElement('div');
            actionsContainer.className = 'toast-actions';
            
            actions.forEach(action => {
                const button = document.createElement('button');
                button.className = `btn btn-${action.type || 'outline'} btn-sm`;
                button.textContent = action.text;
                button.addEventListener('click', () => {
                    if (action.handler) {
                        action.handler();
                    }
                    this.removeToast(toast);
                });
                actionsContainer.appendChild(button);
            });
            
            content.appendChild(actionsContainer);
        }
        
        const closeButton = document.createElement('button');
        closeButton.className = 'toast-close';
        closeButton.innerHTML = '&times;';
        closeButton.setAttribute('aria-label', 'Close notification');
        closeButton.addEventListener('click', () => {
            this.removeToast(toast);
        });
        
        toast.appendChild(content);
        toast.appendChild(closeButton);
        
        this.container.appendChild(toast);
        
        // Add entrance animation
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });
        
        // Auto-remove after duration (if specified)
        if (duration > 0) {
            setTimeout(() => {
                this.removeToast(toast);
            }, duration);
        }
        
        return toast;
    }

    // Show progress toast
    showProgress(message, progress = 0, type = 'info') {
        if (!this.container) {
            this.init();
        }

        const toast = document.createElement('div');
        toast.className = `toast ${type} toast-progress`;
        
        const content = document.createElement('div');
        content.className = 'toast-content';
        
        const messageElement = document.createElement('span');
        messageElement.className = 'toast-message';
        messageElement.textContent = message;
        content.appendChild(messageElement);
        
        // Add progress bar
        const progressContainer = document.createElement('div');
        progressContainer.className = 'toast-progress-container';
        
        const progressBar = document.createElement('div');
        progressBar.className = 'toast-progress-bar';
        progressBar.style.width = `${progress}%`;
        
        progressContainer.appendChild(progressBar);
        content.appendChild(progressContainer);
        
        const closeButton = document.createElement('button');
        closeButton.className = 'toast-close';
        closeButton.innerHTML = '&times;';
        closeButton.setAttribute('aria-label', 'Close notification');
        closeButton.addEventListener('click', () => {
            this.removeToast(toast);
        });
        
        toast.appendChild(content);
        toast.appendChild(closeButton);
        
        this.container.appendChild(toast);
        
        // Add entrance animation
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });
        
        // Store reference for progress updates
        toast.progressBar = progressBar;
        
        return toast;
    }

    // Update progress of a progress toast
    updateProgress(toast, progress) {
        if (toast && toast.progressBar) {
            toast.progressBar.style.width = `${Math.min(100, Math.max(0, progress))}%`;
        }
    }

    // Show toast with countdown
    showWithCountdown(message, countdownSeconds, type = 'info') {
        if (!this.container) {
            this.init();
        }

        const toast = document.createElement('div');
        toast.className = `toast ${type} toast-countdown`;
        
        const content = document.createElement('div');
        content.className = 'toast-content';
        
        const messageElement = document.createElement('span');
        messageElement.className = 'toast-message';
        messageElement.textContent = message;
        content.appendChild(messageElement);
        
        // Add countdown
        const countdownElement = document.createElement('span');
        countdownElement.className = 'toast-countdown-text';
        countdownElement.textContent = `(${countdownSeconds}s)`;
        content.appendChild(countdownElement);
        
        const closeButton = document.createElement('button');
        closeButton.className = 'toast-close';
        closeButton.innerHTML = '&times;';
        closeButton.setAttribute('aria-label', 'Close notification');
        closeButton.addEventListener('click', () => {
            this.removeToast(toast);
        });
        
        toast.appendChild(content);
        toast.appendChild(closeButton);
        
        this.container.appendChild(toast);
        
        // Add entrance animation
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });
        
        // Start countdown
        let remaining = countdownSeconds;
        const countdownInterval = setInterval(() => {
            remaining--;
            countdownElement.textContent = `(${remaining}s)`;
            
            if (remaining <= 0) {
                clearInterval(countdownInterval);
                this.removeToast(toast);
            }
        }, 1000);
        
        // Store interval for cleanup
        toast.countdownInterval = countdownInterval;
        
        return toast;
    }

    // Pause countdown
    pauseCountdown(toast) {
        if (toast && toast.countdownInterval) {
            clearInterval(toast.countdownInterval);
            toast.countdownInterval = null;
        }
    }

    // Resume countdown
    resumeCountdown(toast, remainingSeconds) {
        if (toast && !toast.countdownInterval) {
            let remaining = remainingSeconds;
            const countdownElement = toast.querySelector('.toast-countdown-text');
            
            toast.countdownInterval = setInterval(() => {
                remaining--;
                if (countdownElement) {
                    countdownElement.textContent = `(${remaining}s)`;
                }
                
                if (remaining <= 0) {
                    clearInterval(toast.countdownInterval);
                    this.removeToast(toast);
                }
            }, 1000);
        }
    }
}
