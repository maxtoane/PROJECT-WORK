// ===== AUTHENTICATION MODULE =====
// Handles user registration, login, logout, and session management

export class AuthModule {
    constructor() {
        this.storageKey = 'edughana_users';
        this.sessionKey = 'edughana_session';
        this.init();
    }

    init() {
        // Seed with demo user if no users exist
        if (this.getTotalUsers() === 0) {
            this.seedDemoUser();
        }
    }

    // Simple hash function for passwords (not cryptographically secure, but better than plaintext)
    hashPassword(password) {
        let hash = 0;
        if (password.length === 0) return hash.toString();
        
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        
        return hash.toString();
    }

    // Generate unique user ID
    generateUserId() {
        return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Get all users from localStorage
    getUsers() {
        try {
            const users = localStorage.getItem(this.storageKey);
            return users ? JSON.parse(users) : {};
        } catch (error) {
            console.error('Error reading users from localStorage:', error);
            return {};
        }
    }

    // Save users to localStorage
    saveUsers(users) {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(users));
        } catch (error) {
            console.error('Error saving users to localStorage:', error);
            throw new Error('Failed to save user data');
        }
    }

    // Get total number of registered users
    getTotalUsers() {
        const users = this.getUsers();
        return Object.keys(users).length;
    }

    // Check if email already exists
    emailExists(email) {
        const users = this.getUsers();
        return Object.values(users).some(user => user.email === email);
    }

    // Register new user
    async register(userData) {
        try {
            const { name, email, password } = userData;

            // Validation
            if (!name || !email || !password) {
                throw new Error('All fields are required');
            }

            if (name.length < 2) {
                throw new Error('Name must be at least 2 characters long');
            }

            if (password.length < 6) {
                throw new Error('Password must be at least 6 characters long');
            }

            if (!this.isValidEmail(email)) {
                throw new Error('Please enter a valid email address');
            }

            if (this.emailExists(email)) {
                throw new Error('Email already registered');
            }

            // Create user object
            const user = {
                id: this.generateUserId(),
                name: name.trim(),
                email: email.toLowerCase().trim(),
                password: this.hashPassword(password),
                createdAt: new Date().toISOString(),
                lastLogin: null
            };

            // Save user
            const users = this.getUsers();
            users[user.id] = user;
            this.saveUsers(users);

            // Auto-login after registration
            await this.login(email, password);

            return {
                success: true,
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email
                }
            };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Login user
    async login(email, password) {
        try {
            const users = this.getUsers();
            const user = Object.values(users).find(u => 
                u.email === email.toLowerCase().trim() && 
                u.password === this.hashPassword(password)
            );

            if (!user) {
                throw new Error('Invalid email or password');
            }

            // Update last login
            user.lastLogin = new Date().toISOString();
            users[user.id] = user;
            this.saveUsers(users);

            // Create session
            const session = {
                userId: user.id,
                loginTime: new Date().toISOString(),
                expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
            };

            localStorage.setItem(this.sessionKey, JSON.stringify(session));

            return {
                success: true,
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email
                }
            };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Get current authenticated user
    async getCurrentUser() {
        try {
            const sessionData = localStorage.getItem(this.sessionKey);
            if (!sessionData) {
                return null;
            }

            const session = JSON.parse(sessionData);
            
            // Check if session is expired
            if (new Date(session.expiresAt) < new Date()) {
                this.logout();
                return null;
            }

            const users = this.getUsers();
            const user = users[session.userId];

            if (!user) {
                this.logout();
                return null;
            }

            return {
                id: user.id,
                name: user.name,
                email: user.email
            };

        } catch (error) {
            console.error('Error getting current user:', error);
            this.logout();
            return null;
        }
    }

    // Logout user
    async logout() {
        try {
            localStorage.removeItem(this.sessionKey);
            return { success: true };
        } catch (error) {
            console.error('Error during logout:', error);
            return { success: false, error: error.message };
        }
    }

    // Check if user is authenticated
    isAuthenticated() {
        return this.getCurrentUser() !== null;
    }

    // Validate email format
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Seed demo user for testing
    seedDemoUser() {
        try {
            const demoUser = {
                id: 'demo_user_001',
                name: 'Demo Student',
                email: 'demo@edughana.com',
                password: this.hashPassword('demo123'),
                createdAt: new Date().toISOString(),
                lastLogin: null
            };

            const users = this.getUsers();
            users[demoUser.id] = demoUser;
            this.saveUsers(users);

            console.log('Demo user seeded successfully');
        } catch (error) {
            console.error('Failed to seed demo user:', error);
        }
    }

    // Get demo user credentials
    getDemoCredentials() {
        return {
            email: 'demo@edughana.com',
            password: 'demo123'
        };
    }

    // Change user password
    async changePassword(userId, currentPassword, newPassword) {
        try {
            const users = this.getUsers();
            const user = users[userId];

            if (!user) {
                throw new Error('User not found');
            }

            if (user.password !== this.hashPassword(currentPassword)) {
                throw new Error('Current password is incorrect');
            }

            if (newPassword.length < 6) {
                throw new Error('New password must be at least 6 characters long');
            }

            // Update password
            user.password = this.hashPassword(newPassword);
            users[userId] = user;
            this.saveUsers(users);

            return { success: true };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Delete user account
    async deleteAccount(userId, password) {
        try {
            const users = this.getUsers();
            const user = users[userId];

            if (!user) {
                throw new Error('User not found');
            }

            if (user.password !== this.hashPassword(password)) {
                throw new Error('Password is incorrect');
            }

            // Remove user
            delete users[userId];
            this.saveUsers(users);

            // Logout if it's the current user
            if (this.isAuthenticated()) {
                await this.logout();
            }

            return { success: true };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Get user profile
    getUserProfile(userId) {
        try {
            const users = this.getUsers();
            const user = users[userId];

            if (!user) {
                return null;
            }

            // Return user data without password
            return {
                id: user.id,
                name: user.name,
                email: user.email,
                createdAt: user.createdAt,
                lastLogin: user.lastLogin
            };

        } catch (error) {
            console.error('Error getting user profile:', error);
            return null;
        }
    }

    // Update user profile
    async updateProfile(userId, updates) {
        try {
            const users = this.getUsers();
            const user = users[userId];

            if (!user) {
                throw new Error('User not found');
            }

            // Validate updates
            if (updates.name && updates.name.length < 2) {
                throw new Error('Name must be at least 2 characters long');
            }

            if (updates.email) {
                if (!this.isValidEmail(updates.email)) {
                    throw new Error('Please enter a valid email address');
                }

                // Check if email is already taken by another user
                const emailExists = Object.values(users).some(u => 
                    u.id !== userId && u.email === updates.email.toLowerCase().trim()
                );

                if (emailExists) {
                    throw new Error('Email already taken');
                }
            }

            // Apply updates
            if (updates.name) user.name = updates.name.trim();
            if (updates.email) user.email = updates.email.toLowerCase().trim();

            users[userId] = user;
            this.saveUsers(users);

            return { success: true };

        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }
}
