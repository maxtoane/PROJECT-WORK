// ===== COURSES MODULE =====
// Handles course management and online course searching

export class CoursesModule {
    constructor() {
        this.courses = this.getSampleCourses();
        this.searchResults = [];
        this.currentFilters = {};
        this.init();
    }

    init() {
        // Initialize any necessary setup
        this.loadSavedCourses();
        console.log('Courses module initialized');
    }

    // Load saved courses from localStorage
    loadSavedCourses() {
        try {
            const savedCourses = JSON.parse(localStorage.getItem('edughana_saved_courses') || '[]');
            if (savedCourses.length > 0) {
                this.courses.push(...savedCourses);
                console.log(`Loaded ${savedCourses.length} saved courses`);
            }
        } catch (error) {
            console.error('Failed to load saved courses:', error);
        }
    }

    // Get sample courses data (existing courses)
    getSampleCourses() {
        return [
            {
                id: 'mathematics',
                title: 'Mathematics',
                description: 'Comprehensive coverage of SHS and University Mathematics including Algebra, Geometry, Calculus, and Statistics. Perfect for WASSCE preparation.',
                level: 'SHS/University',
                subject: 'Mathematics',
                image: '📐',
                duration: '12 weeks',
                topics: ['Algebra', 'Geometry', 'Calculus', 'Statistics', 'Trigonometry'],
                source: 'local'
            },
            {
                id: 'english',
                title: 'English Language & Literature',
                description: 'Master English grammar, literature analysis, and writing skills. Essential for academic success and WASSCE English examination.',
                level: 'SHS/University',
                subject: 'English',
                image: '📚',
                duration: '10 weeks',
                topics: ['Grammar', 'Literature', 'Writing', 'Comprehension', 'Poetry'],
                source: 'local'
            },
            {
                id: 'ict',
                title: 'Information & Communication Technology',
                description: 'Learn programming fundamentals, computer science concepts, and practical ICT skills for the digital age.',
                level: 'SHS/University',
                subject: 'ICT',
                image: '💻',
                duration: '14 weeks',
                topics: ['Programming', 'Web Development', 'Databases', 'Networking', 'Cybersecurity'],
                source: 'local'
            },
            {
                id: 'science',
                title: 'Integrated Science',
                description: 'Explore Physics, Chemistry, and Biology concepts with hands-on experiments and real-world applications.',
                level: 'SHS',
                subject: 'Science',
                image: '🔬',
                duration: '16 weeks',
                topics: ['Physics', 'Chemistry', 'Biology', 'Experiments', 'Scientific Method'],
                source: 'local'
            },
            {
                id: 'social-studies',
                title: 'Social Studies',
                description: 'Study Ghana\'s history, geography, economics, and government. Understand your country\'s past and present.',
                level: 'SHS',
                subject: 'Social Studies',
                image: '🌍',
                duration: '12 weeks',
                topics: ['Ghana History', 'Geography', 'Economics', 'Government', 'Culture'],
                source: 'local'
            },
            {
                id: 'programming',
                title: 'Programming Fundamentals',
                description: 'Introduction to programming concepts using Python. Learn variables, loops, functions, and problem-solving.',
                level: 'University',
                subject: 'Computer Science',
                image: '🐍',
                duration: '8 weeks',
                topics: ['Python Basics', 'Variables', 'Loops', 'Functions', 'Data Structures'],
                source: 'local'
            },
            {
                id: 'data-structures',
                title: 'Data Structures & Algorithms',
                description: 'Advanced programming concepts covering arrays, linked lists, trees, graphs, and algorithm analysis.',
                level: 'University',
                subject: 'Computer Science',
                image: '📊',
                duration: '10 weeks',
                topics: ['Arrays', 'Linked Lists', 'Trees', 'Graphs', 'Algorithm Analysis'],
                source: 'local'
            },
            {
                id: 'business',
                title: 'Business Studies',
                description: 'Learn business principles, entrepreneurship, and management concepts relevant to Ghana\'s economy.',
                level: 'SHS/University',
                subject: 'Business',
                image: '💼',
                duration: '12 weeks',
                topics: ['Business Principles', 'Entrepreneurship', 'Management', 'Marketing', 'Finance'],
                source: 'local'
            }
        ];
    }

    // Search for courses online using multiple sources
    async searchOnlineCourses(query, filters = {}) {
        try {
            this.searchResults = [];
            const searchPromises = [];

            // Search Open Library for educational books
            if (query.trim()) {
                searchPromises.push(this.searchOpenLibrary(query));
                searchPromises.push(this.searchWikipedia(query));
                searchPromises.push(this.searchKhanAcademy(query));
            }

            // Wait for all searches to complete
            const results = await Promise.allSettled(searchPromises);
            
            // Process results and add to search results
            results.forEach(result => {
                if (result.status === 'fulfilled' && result.value) {
                    this.searchResults.push(...result.value);
                }
            });

            // Apply filters if provided
            if (Object.keys(filters).length > 0) {
                this.searchResults = this.applyFilters(this.searchResults, filters);
            }

            return this.searchResults;

        } catch (error) {
            console.error('Error searching online courses:', error);
            throw new Error('Failed to search online courses');
        }
    }

    // Search Open Library for educational books
    async searchOpenLibrary(query) {
        try {
            const response = await fetch(`https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&subject=education&limit=10`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (!data.docs || data.docs.length === 0) return [];

            return data.docs.map(book => ({
                id: `ol_${book.key}`,
                title: book.title || 'Untitled',
                description: book.description || 'No description available',
                level: this.determineLevel(book),
                subject: this.determineSubject(book),
                image: '📖',
                duration: 'Self-paced',
                topics: book.subject ? book.subject.slice(0, 5) : [],
                source: 'Open Library',
                url: `https://openlibrary.org${book.key}`,
                author: book.author_name ? book.author_name[0] : 'Unknown Author',
                year: book.first_publish_year || 'Unknown Year'
            }));

        } catch (error) {
            console.error('Open Library search failed:', error);
            return [];
        }
    }

    // Search Wikipedia for educational content
    async searchWikipedia(query) {
        try {
            const response = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`);
            const data = await response.json();
            
            if (data.type === 'standard') {
                return [{
                    id: `wiki_${data.pageid}`,
                    title: data.title,
                    description: data.extract || 'No description available',
                    level: 'General',
                    subject: this.determineSubject({ subject: [data.title] }),
                    image: '🌐',
                    duration: 'Self-paced',
                    topics: [data.title],
                    source: 'Wikipedia',
                    url: data.content_urls?.desktop?.page || data.content_urls?.mobile?.page,
                    author: 'Wikipedia Community',
                    year: 'Current'
                }];
            }

            return [];

        } catch (error) {
            console.error('Wikipedia search failed:', error);
            return [];
        }
    }

    // Search Khan Academy (simulated - using their public API if available)
    async searchKhanAcademy(query) {
        try {
            // Note: Khan Academy doesn't have a public search API, so we'll simulate results
            // In a real implementation, you might use their public content or partner with them
            const simulatedResults = [
                {
                    id: `ka_${Date.now()}`,
                    title: `${query} - Khan Academy Course`,
                    description: `Comprehensive ${query} course with video lessons, practice exercises, and assessments.`,
                    level: 'All Levels',
                    subject: this.determineSubject({ subject: [query] }),
                    image: '🎓',
                    duration: 'Self-paced',
                    topics: [query, 'Video Lessons', 'Practice Exercises', 'Assessments'],
                    source: 'Khan Academy',
                    url: `https://www.khanacademy.org/search?page_search_query=${encodeURIComponent(query)}`,
                    author: 'Khan Academy',
                    year: 'Current'
                }
            ];

            return simulatedResults;

        } catch (error) {
            console.error('Khan Academy search failed:', error);
            return [];
        }
    }

    // Determine course level based on content
    determineLevel(book) {
        if (book.subject) {
            const subjects = book.subject.join(' ').toLowerCase();
            if (subjects.includes('university') || subjects.includes('college')) return 'University';
            if (subjects.includes('high school') || subjects.includes('secondary')) return 'SHS';
            if (subjects.includes('primary') || subjects.includes('elementary')) return 'Primary';
        }
        return 'General';
    }

    // Determine subject based on content
    determineSubject(book) {
        if (book.subject && book.subject.length > 0) {
            const mainSubject = book.subject[0];
            if (mainSubject.includes('Mathematics') || mainSubject.includes('Math')) return 'Mathematics';
            if (mainSubject.includes('Science')) return 'Science';
            if (mainSubject.includes('English') || mainSubject.includes('Literature')) return 'English';
            if (mainSubject.includes('Computer') || mainSubject.includes('Programming')) return 'ICT';
            if (mainSubject.includes('Business') || mainSubject.includes('Economics')) return 'Business';
            if (mainSubject.includes('History') || mainSubject.includes('Geography')) return 'Social Studies';
        }
        return 'General';
    }

    // Apply filters to search results
    applyFilters(results, filters) {
        return results.filter(result => {
            if (filters.level && filters.level !== 'all' && result.level !== filters.level) {
                return false;
            }
            if (filters.subject && filters.subject !== 'all' && result.subject !== filters.subject) {
                return false;
            }
            if (filters.source && filters.source !== 'all' && result.source !== filters.source) {
                return false;
            }
            return true;
        });
    }

    // Get all courses (local + search results)
    getAllCourses() {
        return [...this.courses, ...this.searchResults];
    }

    // Get course by ID
    getCourseById(id) {
        const allCourses = this.getAllCourses();
        return allCourses.find(course => course.id === id);
    }

    // Get courses by subject
    getCoursesBySubject(subject) {
        const allCourses = this.getAllCourses();
        return allCourses.filter(course => course.subject === subject);
    }

    // Get courses by level
    getCoursesByLevel(level) {
        const allCourses = this.getAllCourses();
        return allCourses.filter(course => course.level === level);
    }

    // Clear search results
    clearSearchResults() {
        this.searchResults = [];
    }

    // Get trending topics for course suggestions
    getTrendingTopics() {
        return [
            'Mathematics',
            'Programming',
            'Science',
            'English Literature',
            'Ghana History',
            'Computer Science',
            'Business Studies',
            'Physics',
            'Chemistry',
            'Biology'
        ];
    }
}
