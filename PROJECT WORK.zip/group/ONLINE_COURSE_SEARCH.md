# Online Course Search Functionality

## Overview
EduGhana now includes a powerful online course search feature that allows students to discover additional educational content from trusted external sources.

## Features

### 🔍 Multi-Source Search
- **Open Library**: Search educational books and resources
- **Wikipedia**: Find comprehensive articles on various topics
- **Khan Academy**: Discover structured learning materials (simulated)

### 📚 Course Discovery
- Search for any topic or subject
- Filter results by level (SHS, University, General)
- Filter results by subject area
- View course details including topics, author, and source

### 💾 Save to Library
- Save interesting online courses to your personal library
- Courses are stored locally and persist between sessions
- Access saved courses alongside built-in courses

### 🔥 Trending Topics
- Quick access to popular search terms
- Click to instantly search for trending topics
- Helps students discover new learning opportunities

## How to Use

### 1. Access Online Search
- Navigate to the Courses page
- Scroll down to the "🌐 Search Online Courses" section

### 2. Search for Courses
- Enter your search query (e.g., "Python programming", "Calculus", "Ghana history")
- Click "Search Online" button
- View results from multiple sources

### 3. Filter Results
- Use the level and subject filters to narrow down results
- Filters apply to both local and online courses

### 4. Save Courses
- Click "Save to Library" on any online course
- Course will be added to your personal collection
- Access saved courses in the main courses grid

### 5. Explore Trending Topics
- Click on trending topic buttons for instant searches
- Discover popular subjects and learning areas

## Technical Implementation

### Backend APIs
- **Open Library API**: `https://openlibrary.org/search.json`
- **Wikipedia API**: `https://en.wikipedia.org/api/rest_v1/page/summary/`
- **Khan Academy**: Simulated results (no public API available)

### Data Structure
```javascript
{
    id: 'unique_id',
    title: 'Course Title',
    description: 'Course description',
    level: 'SHS/University/General',
    subject: 'Subject area',
    image: '📚',
    duration: 'Self-paced',
    topics: ['topic1', 'topic2'],
    source: 'Source name',
    url: 'External URL',
    author: 'Author name',
    year: 'Publication year'
}
```

### Local Storage
- Saved courses are stored in `localStorage.edughana_saved_courses`
- Courses persist between browser sessions
- Automatic loading on page refresh

## Benefits for Ghanaian Students

### 🌍 Expanded Learning Resources
- Access to international educational content
- Discover courses not available locally
- Learn from diverse perspectives and approaches

### 📱 Mobile-Friendly
- Responsive design works on all devices
- Optimized for students with limited desktop access
- Fast search and results display

### 🎯 Curriculum Alignment
- Search results are categorized by Ghanaian education levels
- Subject classification matches local curriculum
- WASSCE and University preparation support

### 💡 Self-Directed Learning
- Students can explore topics of personal interest
- Build custom learning paths
- Supplement classroom education

## Future Enhancements

### Planned Features
- **More Sources**: Integration with additional educational platforms
- **Advanced Filters**: Difficulty level, language, and format filters
- **Course Recommendations**: AI-powered course suggestions
- **Progress Tracking**: Track learning progress across online courses
- **Offline Access**: Download courses for offline study

### API Improvements
- **Rate Limiting**: Better handling of API quotas
- **Caching**: Improved performance with result caching
- **Fallback Sources**: Alternative APIs when primary sources fail

## Troubleshooting

### Common Issues
1. **No Results Found**: Try different keywords or check spelling
2. **Search Failed**: Check internet connection and try again
3. **Course Won't Save**: Ensure you're logged in and try refreshing

### Performance Tips
- Use specific search terms for better results
- Combine filters to narrow down results
- Save frequently accessed courses to your library

## Support

For technical support or feature requests related to online course search, please contact the EduGhana development team.

---

*This feature is designed to enhance the learning experience for Ghanaian students by providing access to a wider range of educational resources.*
