# Waste Manifest & Weighbridge Tracking System

Tracks trucks moving waste between sites (generator site → sorting station →
landfill) through a two-step verification lifecycle: an **Origin Dispatch
Ticket** and a **Destination Discharge Receipt**, linked by a scannable QR
code.

## What's actually built vs. what's a documented next step

Being upfront about this matters more than a glossy checklist. This was built
and verified inside a sandboxed environment with no phones, no Bluetooth
stack, and no mobile build toolchain (Xcode/Android Studio) attached — so:

**Built, running, and tested (curl'd through the full lifecycle personally
before being written up here):**
- Backend API — Express + SQLite, real JWT auth, bcrypt password hashing,
  role-based access (admin / origin_operator / destination_operator / driver)
- Full manifest lifecycle: `draft → dispatched → in_transit → received →
  closed`, with weight math (net = gross − tare, clamped at zero) and
  disposal-fee calculation against configurable per-site/per-waste-type rates
- Real QR generation (`qrcode` library) with an HMAC checksum embedded in the
  payload, verified server-side on scan — a forged or guessed code is rejected
- Full audit trail (`manifest_events`) — every transition logged with who,
  when, and from which device
- An offline-sync **endpoint** (`POST /api/sync`) that accepts a queued batch
  of events from a device and applies them with last-write-wins semantics
- CSV export and a summary/reporting endpoint (tonnage, revenue, open/closed
  counts)
- Two print templates (58mm dispatch ticket, 80mm discharge receipt), sized
  correctly in actual printer **dots** (not CSS mm — see the note in
  `print-templates/dispatch-ticket-58mm.html` on why that distinction
  matters), verified by rendering them at real thermal-printer resolution

**Not built here — needs a mobile dev environment and real hardware:**
- The React Native origin/destination/driver apps themselves. The API above
  is what they'd call; the print templates above are the exact layout spec
  they'd implement natively.
- Real Bluetooth ESC/POS printing. Browsers cannot talk to Bluetooth
  printers directly — see the comment block in the print templates for the
  concrete library recommendations (`react-native-esc-pos-printer` or
  `react-native-thermal-receipt-printer`) and the bitmap-to-raster pipeline
  those use.
- Local on-device offline storage (SQLite/WatermelonDB/Realm) and the
  background sync trigger that calls `/api/sync` when connectivity returns.
  The server side of that contract exists and is tested; the device side
  needs an actual app shell to live in.
- A real weighbridge serial/TCP integration — `gross_weight_kg` is currently
  posted as a plain number in the request body, standing in for wherever
  that number will come from (manual entry today, a serial-connected scale
  later).
- Docker packaging and a Postgres migration (see below).

## Architecture

```
Origin Site  --(dispatch, prints ticket)-->  [truck travels with QR]  --(scan)-->  Destination Site
     |                                                                                    |
     +--------------------------- both write to -----------------------------------------+
                                            |
                                     Backend API (this repo)
                                    Express + SQLite + JWT
                                            |
                                   Admin dashboard (web)
```

Each site's app only needs the backend's URL and a logged-in operator
account — there's no direct site-to-site communication, which is what makes
the offline queue-and-sync model work: a site can operate fully
disconnected and reconcile later.

## Database schema

See `migrations/001_init.sql` for the full schema with comments. Tables:
`tenants`, `users`, `sites`, `waste_types`, `rates`, `trucks`, `drivers`,
`manifests` (the core lifecycle table), `manifest_events` (audit trail),
`sync_queue` (offline reconciliation log).

Multi-tenant from the start — every table hangs off `tenant_id`, so multiple
landfills/companies can run on the same deployment without seeing each
other's data.

## Setup

```bash
cd backend
npm install
npm run seed     # creates a demo tenant, one user per role, 3 sites, rates
npm start         # http://localhost:4100
```

Demo accounts (printed by the seed script, and reproduced here):
| Role | Email | Password |
|---|---|---|
| admin | admin@wastetrack.local | Admin@123 |
| origin_operator | origin@wastetrack.local | Origin@123 |
| destination_operator | weighbridge@wastetrack.local | Weigh@123 |
| driver | driver@wastetrack.local | Driver@123 |

## Trying the full lifecycle yourself

```bash
# 1. Log in as the origin operator
TOKEN=$(curl -s -X POST localhost:4100/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"origin@wastetrack.local","password":"Origin@123"}' | jq -r .token)

# 2. Create a draft manifest (tare weight captured at loading)
curl -s -X POST localhost:4100/api/manifests -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"origin_site_id":1,"destination_site_id":3,"truck_id":1,"driver_id":1,"waste_type_id":1,"tare_weight_kg":6000}'

# 3. Dispatch it (truck leaves) — use the returned "id"
curl -s -X POST localhost:4100/api/manifests/1/dispatch -H "Authorization: Bearer $TOKEN"

# 4. As the destination operator, scan it using the returned uuid + qr_checksum
curl -s localhost:4100/api/manifests/scan/<uuid>/<checksum> -H "Authorization: Bearer $WEIGH_TOKEN"

# 5. Weigh and close it
curl -s -X POST localhost:4100/api/manifests/1/weigh -H "Authorization: Bearer $WEIGH_TOKEN" \
  -H "Content-Type: application/json" -d '{"gross_weight_kg":9200}'
```

## Roadmap to the full spec

In priority order, since a client conversation about sequencing will matter
more than a fixed date:

1. **Mobile apps (React Native)** — three thin clients against the existing
   API: Origin (create/dispatch), Destination (scan/weigh/close), Driver
   (view assigned trip, digital signature). This is the largest remaining
   piece of work.
2. **Offline storage + sync trigger** on-device, calling the already-built
   `/api/sync` endpoint.
3. **Bluetooth ESC/POS printing**, using the two verified templates as the
   exact spec.
4. **Postgres migration** — schema is already written in portable SQL;
   swapping `better-sqlite3` for `pg` and adjusting the few SQLite-specific
   functions (`datetime('now')` etc.) is a contained, mechanical change.
5. **Docker Compose** — API + Postgres + Redis, once the Postgres migration
   lands.
6. **Admin web dashboard** — live truck status, daily tonnage, revenue,
   open/closed manifests. The `/api/reports/summary` and `/api/manifests`
   endpoints already provide everything it needs to render.
