const crypto = require('crypto');

const QR_SECRET = process.env.QR_SECRET || 'dev-qr-secret-change-in-production';

/** Short, non-guessable checksum embedded in the QR so a scanned code can be
 *  validated server-side without trusting the client blindly. */
function checksumFor(uuid) {
  return crypto.createHmac('sha256', QR_SECRET).update(uuid).digest('hex').slice(0, 10);
}

function verifyChecksum(uuid, checksum) {
  return checksumFor(uuid) === checksum;
}

/** Sequential human-readable manifest number, e.g. MAN-000123.
 *  Real production deployments with multiple sites writing concurrently should
 *  use a DB sequence per tenant rather than MAX(id)+1 to avoid race conditions —
 *  noted in the README as a hardening item before go-live. */
function nextManifestNumber(db, tenantId) {
  const row = db.prepare('SELECT COUNT(*) as n FROM manifests WHERE tenant_id = ?').get(tenantId);
  return `MAN-${String(row.n + 1).padStart(6, '0')}`;
}

/** Net weight = gross - tare, clamped so it can never go negative — a data
 *  entry error at the scale should never produce a negative disposal fee. */
function computeNetWeight(grossKg, tareKg) {
  const net = Number(grossKg) - Number(tareKg || 0);
  return Math.max(0, Math.round(net * 100) / 100);
}

function computeDisposalFee(netKg, ratePerTon) {
  return Math.round((netKg / 1000) * Number(ratePerTon) * 100) / 100;
}

module.exports = { checksumFor, verifyChecksum, nextManifestNumber, computeNetWeight, computeDisposalFee };
