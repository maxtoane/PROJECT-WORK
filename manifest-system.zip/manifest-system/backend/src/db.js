const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'manifest.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Run migrations (idempotent — CREATE TABLE IF NOT EXISTS throughout)
const migrationsDir = path.join(__dirname, '..', 'migrations');
for (const file of fs.readdirSync(migrationsDir).sort()) {
  const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
  db.exec(sql);
}

module.exports = db;
