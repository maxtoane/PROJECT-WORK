const bcrypt = require('bcryptjs');
const db = require('./db');

const tenant = db.prepare('INSERT INTO tenants (name) VALUES (?)').run('Demo Waste Management Co.');
const tenantId = tenant.lastInsertRowid;

function user(name, email, password, role, siteId) {
  db.prepare('INSERT INTO users (tenant_id, name, email, password_hash, role, site_id) VALUES (?,?,?,?,?,?)')
    .run(tenantId, name, email, bcrypt.hashSync(password, 10), role, siteId || null);
  console.log(`  ${role.padEnd(22)} ${email} / ${password}`);
}

const generator = db.prepare('INSERT INTO sites (tenant_id, name, site_type, address) VALUES (?,?,?,?)')
  .run(tenantId, 'Accra Central Generator Site', 'generator', 'Accra Central, Ghana').lastInsertRowid;
const sorting = db.prepare('INSERT INTO sites (tenant_id, name, site_type, address) VALUES (?,?,?,?)')
  .run(tenantId, 'Tema Sorting Station', 'sorting_station', 'Tema, Ghana').lastInsertRowid;
const landfill = db.prepare('INSERT INTO sites (tenant_id, name, site_type, address) VALUES (?,?,?,?)')
  .run(tenantId, 'Kpone Engineered Landfill', 'landfill', 'Kpone, Ghana').lastInsertRowid;

console.log('Demo accounts:');
user('Platform Admin', 'admin@wastetrack.local', 'Admin@123', 'admin');
user('Kojo Mensah', 'origin@wastetrack.local', 'Origin@123', 'origin_operator', generator);
user('Ama Serwaa', 'weighbridge@wastetrack.local', 'Weigh@123', 'destination_operator', landfill);
user('Yaw Boateng', 'driver@wastetrack.local', 'Driver@123', 'driver');

const municipal = db.prepare('INSERT INTO waste_types (tenant_id, name) VALUES (?,?)').run(tenantId, 'Municipal').lastInsertRowid;
db.prepare('INSERT INTO waste_types (tenant_id, name) VALUES (?,?)').run(tenantId, 'Hazardous');
db.prepare('INSERT INTO waste_types (tenant_id, name) VALUES (?,?)').run(tenantId, 'Construction');

db.prepare('INSERT INTO rates (tenant_id, site_id, waste_type_id, rate_per_ton, currency) VALUES (?,?,?,?,?)')
  .run(tenantId, landfill, municipal, 45.0, 'GHS');

db.prepare('INSERT INTO trucks (tenant_id, plate_no, carrier, capacity_kg) VALUES (?,?,?,?)').run(tenantId, 'GT-4521-20', 'CityWaste Haulage', 8000);
db.prepare('INSERT INTO drivers (tenant_id, name, phone, licence_no) VALUES (?,?,?,?)').run(tenantId, 'Yaw Boateng', '+233 24 111 2233', 'GHA-DL-55210');

console.log('\nSites: Accra Central Generator Site -> Tema Sorting Station -> Kpone Engineered Landfill');
console.log('Rate configured: Municipal @ GHS 45.00/ton at Kpone landfill');
console.log('Seed complete.');
