const express = require('express');
const path = require('path');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const QRCode = require('qrcode');

const db = require('./db');
const { signToken, requireAuth, requireRole } = require('./auth');
const { checksumFor, verifyChecksum, nextManifestNumber, computeNetWeight, computeDisposalFee } = require('./utils');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' })); // signatures are base64 PNGs, can be a few hundred KB
app.use(express.static(path.join(__dirname, '..', 'public')));

function logEvent(manifestId, eventType, payload, userId, deviceId, occurredAt) {
  db.prepare(`INSERT INTO manifest_events (manifest_id, event_uuid, event_type, payload_json, user_id, device_id, occurred_at)
              VALUES (?,?,?,?,?,?,?)`)
    .run(manifestId, uuidv4(), eventType, JSON.stringify(payload || {}), userId || null, deviceId || null, occurredAt || new Date().toISOString());
}

/* ===================== AUTH ===================== */

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ? AND active = 1').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  db.prepare('UPDATE users SET last_login = datetime(\'now\') WHERE id = ?').run(user.id);
  const token = signToken(user);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role, tenant_id: user.tenant_id } });
});

app.get('/api/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT id, name, email, role, tenant_id, site_id, last_login FROM users WHERE id = ?').get(req.user.id);
  res.json(user);
});

/* ===================== MASTER DATA ===================== */

app.get('/api/sites', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM sites WHERE tenant_id = ? ORDER BY name').all(req.user.tenant_id));
});
app.post('/api/sites', requireAuth, requireRole('admin'), (req, res) => {
  const { name, site_type, address } = req.body;
  const info = db.prepare('INSERT INTO sites (tenant_id, name, site_type, address) VALUES (?,?,?,?)')
    .run(req.user.tenant_id, name, site_type, address || '');
  res.status(201).json({ id: info.lastInsertRowid });
});

app.get('/api/waste-types', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM waste_types WHERE tenant_id = ? ORDER BY name').all(req.user.tenant_id));
});
app.post('/api/waste-types', requireAuth, requireRole('admin'), (req, res) => {
  const info = db.prepare('INSERT INTO waste_types (tenant_id, name) VALUES (?,?)').run(req.user.tenant_id, req.body.name);
  res.status(201).json({ id: info.lastInsertRowid });
});

app.get('/api/rates', requireAuth, (req, res) => {
  res.json(db.prepare(`SELECT r.*, s.name as site_name, w.name as waste_type_name
                        FROM rates r JOIN sites s ON s.id=r.site_id JOIN waste_types w ON w.id=r.waste_type_id
                        WHERE r.tenant_id = ? ORDER BY r.effective_from DESC`).all(req.user.tenant_id));
});
app.post('/api/rates', requireAuth, requireRole('admin'), (req, res) => {
  const { site_id, waste_type_id, rate_per_ton, currency } = req.body;
  const info = db.prepare('INSERT INTO rates (tenant_id, site_id, waste_type_id, rate_per_ton, currency) VALUES (?,?,?,?,?)')
    .run(req.user.tenant_id, site_id, waste_type_id, rate_per_ton, currency || 'GHS');
  res.status(201).json({ id: info.lastInsertRowid });
});

app.get('/api/trucks', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM trucks WHERE tenant_id = ? ORDER BY plate_no').all(req.user.tenant_id));
});
app.post('/api/trucks', requireAuth, requireRole('admin', 'origin_operator'), (req, res) => {
  const { plate_no, carrier, capacity_kg } = req.body;
  const info = db.prepare('INSERT INTO trucks (tenant_id, plate_no, carrier, capacity_kg) VALUES (?,?,?,?)')
    .run(req.user.tenant_id, plate_no, carrier || '', capacity_kg || null);
  res.status(201).json({ id: info.lastInsertRowid });
});

app.get('/api/drivers', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM drivers WHERE tenant_id = ? ORDER BY name').all(req.user.tenant_id));
});
app.post('/api/drivers', requireAuth, requireRole('admin', 'origin_operator'), (req, res) => {
  const { name, phone, licence_no } = req.body;
  const info = db.prepare('INSERT INTO drivers (tenant_id, name, phone, licence_no) VALUES (?,?,?,?)')
    .run(req.user.tenant_id, name, phone || '', licence_no || '');
  res.status(201).json({ id: info.lastInsertRowid });
});

/* ===================== MANIFEST LIFECYCLE ===================== */
/*  draft -> dispatched -> in_transit -> received -> closed          */
/*  (void is a side-exit available from any non-closed state)        */

function fullManifest(id, tenantId) {
  return db.prepare(`
    SELECT m.*, s1.name as origin_name, s2.name as destination_name,
           t.plate_no, t.carrier, d.name as driver_name, d.phone as driver_phone,
           w.name as waste_type_name
    FROM manifests m
    LEFT JOIN sites s1 ON s1.id = m.origin_site_id
    LEFT JOIN sites s2 ON s2.id = m.destination_site_id
    LEFT JOIN trucks t ON t.id = m.truck_id
    LEFT JOIN drivers d ON d.id = m.driver_id
    LEFT JOIN waste_types w ON w.id = m.waste_type_id
    WHERE m.id = ? AND m.tenant_id = ?
  `).get(id, tenantId);
}

// 1. ORIGIN: create a draft manifest (tare weight captured at loading)
app.post('/api/manifests', requireAuth, requireRole('admin', 'origin_operator'), (req, res) => {
  const { origin_site_id, destination_site_id, truck_id, driver_id, waste_type_id, tare_weight_kg, estimated_weight_kg } = req.body;
  if (!origin_site_id || !waste_type_id) return res.status(400).json({ error: 'origin_site_id and waste_type_id are required' });

  const uuid = uuidv4();
  const checksum = checksumFor(uuid);
  const manifest_number = nextManifestNumber(db, req.user.tenant_id);

  const info = db.prepare(`
    INSERT INTO manifests (tenant_id, manifest_number, uuid, qr_checksum, status,
      origin_site_id, destination_site_id, truck_id, driver_id, waste_type_id,
      tare_weight_kg, estimated_weight_kg, origin_operator_id)
    VALUES (?,?,?,?, 'draft', ?,?,?,?,?, ?,?, ?)
  `).run(req.user.tenant_id, manifest_number, uuid, checksum,
    origin_site_id, destination_site_id || null, truck_id || null, driver_id || null, waste_type_id,
    tare_weight_kg || null, estimated_weight_kg || null, req.user.id);

  logEvent(info.lastInsertRowid, 'created', req.body, req.user.id, req.body.device_id);
  res.status(201).json(fullManifest(info.lastInsertRowid, req.user.tenant_id));
});

// 2. ORIGIN: dispatch — locks in time_out + signature, truck now "in transit"
app.post('/api/manifests/:id/dispatch', requireAuth, requireRole('admin', 'origin_operator'), (req, res) => {
  const m = fullManifest(req.params.id, req.user.tenant_id);
  if (!m) return res.status(404).json({ error: 'Manifest not found' });
  if (m.status !== 'draft') return res.status(409).json({ error: `Cannot dispatch a manifest in status "${m.status}"` });

  const { origin_signature } = req.body;
  db.prepare(`UPDATE manifests SET status='in_transit', time_out=datetime('now'), origin_signature=?, updated_at=datetime('now') WHERE id=?`)
    .run(origin_signature || null, m.id);
  logEvent(m.id, 'dispatched', { device_id: req.body.device_id }, req.user.id, req.body.device_id);
  res.json(fullManifest(m.id, req.user.tenant_id));
});

// 3. DESTINATION: scan the QR to pull up the manifest for weighing.
// Validates the checksum server-side so a forged/guessed code is rejected.
app.get('/api/manifests/scan/:uuid/:checksum', requireAuth, requireRole('admin', 'destination_operator'), (req, res) => {
  const { uuid, checksum } = req.params;
  if (!verifyChecksum(uuid, checksum)) return res.status(400).json({ error: 'Invalid or tampered QR code' });

  const m = db.prepare('SELECT * FROM manifests WHERE uuid = ? AND tenant_id = ?').get(uuid, req.user.tenant_id);
  if (!m) return res.status(404).json({ error: 'No manifest matches this QR code' });
  if (m.status === 'closed' || m.status === 'void') return res.status(409).json({ error: `This manifest is already ${m.status}` });

  if (m.status === 'in_transit') {
    db.prepare(`UPDATE manifests SET status='received', time_in_destination=datetime('now'), updated_at=datetime('now') WHERE id=?`).run(m.id);
    logEvent(m.id, 'scanned', { device_id: req.query.device_id }, req.user.id, req.query.device_id);
  }
  res.json(fullManifest(m.id, req.user.tenant_id));
});

// 4. DESTINATION: record the weighbridge reading, compute net + fee, close it out
app.post('/api/manifests/:id/weigh', requireAuth, requireRole('admin', 'destination_operator'), (req, res) => {
  const m = fullManifest(req.params.id, req.user.tenant_id);
  if (!m) return res.status(404).json({ error: 'Manifest not found' });
  if (!['received', 'in_transit'].includes(m.status)) {
    return res.status(409).json({ error: `Cannot weigh a manifest in status "${m.status}" — scan it first` });
  }

  const { gross_weight_kg, destination_signature, driver_signature } = req.body;
  if (gross_weight_kg == null) return res.status(400).json({ error: 'gross_weight_kg is required' });

  const net = computeNetWeight(gross_weight_kg, m.tare_weight_kg);

  // Look up the configured rate for this site + waste type; fall back to any manually posted rate
  const rateRow = db.prepare(`SELECT rate_per_ton FROM rates WHERE tenant_id=? AND site_id=? AND waste_type_id=? ORDER BY effective_from DESC LIMIT 1`)
    .get(req.user.tenant_id, m.destination_site_id, m.waste_type_id);
  const ratePerTon = rateRow ? rateRow.rate_per_ton : (req.body.rate_per_ton || 0);
  const fee = computeDisposalFee(net, ratePerTon);

  db.prepare(`
    UPDATE manifests SET
      status='closed', gross_weight_kg=?, net_weight_kg=?, rate_per_ton=?, disposal_fee=?,
      destination_operator_id=?, destination_signature=?, driver_signature=?,
      closed_at=datetime('now'), updated_at=datetime('now')
    WHERE id=?
  `).run(gross_weight_kg, net, ratePerTon, fee, req.user.id, destination_signature || null, driver_signature || null, m.id);

  logEvent(m.id, 'closed', { gross_weight_kg, net_weight_kg: net, disposal_fee: fee, device_id: req.body.device_id }, req.user.id, req.body.device_id);
  res.json(fullManifest(m.id, req.user.tenant_id));
});

app.post('/api/manifests/:id/void', requireAuth, requireRole('admin'), (req, res) => {
  const m = fullManifest(req.params.id, req.user.tenant_id);
  if (!m) return res.status(404).json({ error: 'Manifest not found' });
  if (m.status === 'closed') return res.status(409).json({ error: 'Cannot void a closed manifest' });
  db.prepare(`UPDATE manifests SET status='void', updated_at=datetime('now') WHERE id=?`).run(m.id);
  logEvent(m.id, 'voided', { reason: req.body.reason }, req.user.id, req.body.device_id);
  res.json(fullManifest(m.id, req.user.tenant_id));
});

app.get('/api/manifests', requireAuth, (req, res) => {
  const { status } = req.query;
  const baseSelect = `SELECT m.*, s1.name as origin_name, s2.name as destination_name, t.plate_no, d.name as driver_name, w.name as waste_type_name
                       FROM manifests m
                       LEFT JOIN sites s1 ON s1.id=m.origin_site_id
                       LEFT JOIN sites s2 ON s2.id=m.destination_site_id
                       LEFT JOIN trucks t ON t.id=m.truck_id
                       LEFT JOIN drivers d ON d.id=m.driver_id
                       LEFT JOIN waste_types w ON w.id=m.waste_type_id`;
  const rows = status
    ? db.prepare(`${baseSelect} WHERE m.tenant_id=? AND m.status=? ORDER BY m.created_at DESC`).all(req.user.tenant_id, status)
    : db.prepare(`${baseSelect} WHERE m.tenant_id=? ORDER BY m.created_at DESC`).all(req.user.tenant_id);
  res.json(rows);
});

app.get('/api/manifests/:id', requireAuth, (req, res) => {
  const m = fullManifest(req.params.id, req.user.tenant_id);
  if (!m) return res.status(404).json({ error: 'Not found' });
  const events = db.prepare('SELECT * FROM manifest_events WHERE manifest_id=? ORDER BY occurred_at').all(m.id);
  res.json({ ...m, events });
});

// QR image for a manifest — embeds "MANIFEST:<uuid>:<checksum>" so any generic
// QR scanner (or the destination app's camera) can read it, and the checksum
// stops someone from hand-typing a guessed manifest id to close it early.
app.get('/api/manifests/:id/qr', requireAuth, async (req, res) => {
  const m = fullManifest(req.params.id, req.user.tenant_id);
  if (!m) return res.status(404).end();
  const payload = `MANIFEST:${m.uuid}:${m.qr_checksum}`;
  const buffer = await QRCode.toBuffer(payload, { width: 320, margin: 2, color: { dark: '#1B4F72', light: '#ffffff' } });
  res.type('png').send(buffer);
});

/* ===================== OFFLINE SYNC ===================== */
/*  Mobile apps queue events locally (SQLite/WatermelonDB) while offline and
 *  POST the whole queue here once connectivity returns. Conflict rule:
 *  last-write-wins by client_timestamp, but every event is still logged to
 *  manifest_events regardless — so even a "losing" write is auditable, not
 *  silently dropped. */
app.post('/api/sync', requireAuth, (req, res) => {
  const { device_id, queue } = req.body; // queue: [{entity_type, entity_uuid, operation, payload_json, client_timestamp}]
  if (!Array.isArray(queue)) return res.status(400).json({ error: 'queue must be an array' });

  const results = queue.map(item => {
    db.prepare(`INSERT INTO sync_queue (device_id, entity_type, entity_uuid, operation, payload_json, client_timestamp, status, resolved_at)
                VALUES (?,?,?,?,?,?, 'applied', datetime('now'))`)
      .run(device_id, item.entity_type, item.entity_uuid, item.operation, JSON.stringify(item.payload_json || {}), item.client_timestamp);

    if (item.entity_type === 'manifest_event') {
      const m = db.prepare('SELECT id FROM manifests WHERE uuid = ? AND tenant_id = ?').get(item.entity_uuid, req.user.tenant_id);
      if (m) logEvent(m.id, item.payload_json?.event_type || 'synced_event', item.payload_json, req.user.id, device_id, item.client_timestamp);
    }
    return { entity_uuid: item.entity_uuid, status: 'applied' };
  });

  res.json({ synced: results.length, results });
});

/* ===================== REPORTS ===================== */

app.get('/api/reports/summary', requireAuth, (req, res) => {
  const tenantId = req.user.tenant_id;
  const totals = db.prepare(`SELECT
      COUNT(*) as total_manifests,
      COALESCE(SUM(CASE WHEN status='closed' THEN 1 ELSE 0 END),0) as closed_count,
      COALESCE(SUM(CASE WHEN status NOT IN ('closed','void') THEN 1 ELSE 0 END),0) as open_count,
      COALESCE(SUM(CASE WHEN status='closed' THEN net_weight_kg END),0) as total_tonnage_kg,
      COALESCE(SUM(CASE WHEN status='closed' THEN disposal_fee END),0) as total_revenue
    FROM manifests WHERE tenant_id=?`).get(tenantId);
  res.json(totals);
});

app.get('/api/reports/export.csv', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT m.manifest_number, m.status, s1.name as origin, s2.name as destination,
           t.plate_no, d.name as driver, w.name as waste_type,
           m.tare_weight_kg, m.gross_weight_kg, m.net_weight_kg, m.rate_per_ton, m.disposal_fee,
           m.time_out, m.time_in_destination, m.closed_at
    FROM manifests m
    LEFT JOIN sites s1 ON s1.id=m.origin_site_id LEFT JOIN sites s2 ON s2.id=m.destination_site_id
    LEFT JOIN trucks t ON t.id=m.truck_id LEFT JOIN drivers d ON d.id=m.driver_id LEFT JOIN waste_types w ON w.id=m.waste_type_id
    WHERE m.tenant_id=? ORDER BY m.created_at DESC
  `).all(req.user.tenant_id);

  const header = Object.keys(rows[0] || { manifest_number: '' }).join(',');
  const body = rows.map(r => Object.values(r).map(v => `"${v ?? ''}"`).join(',')).join('\n');
  res.type('text/csv').attachment('manifests.csv').send(header + '\n' + body);
});

const PORT = process.env.PORT || 4100;
app.listen(PORT, () => console.log(`Manifest system API running on http://localhost:${PORT}`));
