-- =========================================================
-- Waste Manifest & Weighbridge Tracking System — Schema
-- SQLite syntax (backend uses better-sqlite3). Same shape
-- ports directly to PostgreSQL for the production deployment
-- described in the README (swap AUTOINCREMENT -> SERIAL,
-- TEXT timestamps -> TIMESTAMPTZ).
-- =========================================================

-- Multi-tenant root: each landfill/company operating this system
CREATE TABLE IF NOT EXISTS tenants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','origin_operator','destination_operator','driver')),
  site_id INTEGER REFERENCES sites(id), -- operators are usually tied to one site
  active INTEGER DEFAULT 1,
  last_login TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

-- A "site" is any node in the chain: generator site, sorting station, or landfill
CREATE TABLE IF NOT EXISTS sites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  site_type TEXT NOT NULL CHECK(site_type IN ('generator','sorting_station','landfill')),
  address TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS waste_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL, -- e.g. Municipal, Hazardous, Construction
  UNIQUE(tenant_id, name)
);

-- Disposal rate, configurable per site + waste type, with effective dating
-- so historical manifests keep the rate that applied when they were closed
CREATE TABLE IF NOT EXISTS rates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id),
  site_id INTEGER NOT NULL REFERENCES sites(id),
  waste_type_id INTEGER NOT NULL REFERENCES waste_types(id),
  rate_per_ton REAL NOT NULL,
  currency TEXT DEFAULT 'GHS',
  effective_from TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS trucks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id),
  plate_no TEXT NOT NULL,
  carrier TEXT,
  capacity_kg REAL,
  UNIQUE(tenant_id, plate_no)
);

CREATE TABLE IF NOT EXISTS drivers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id),
  name TEXT NOT NULL,
  phone TEXT,
  licence_no TEXT
);

-- ===================== THE CORE TABLE =====================
-- One row per trip, carried through the full lifecycle:
-- draft -> dispatched -> in_transit -> received -> closed
CREATE TABLE IF NOT EXISTS manifests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL REFERENCES tenants(id),
  manifest_number TEXT UNIQUE NOT NULL,   -- human-readable sequential, e.g. MAN-000123
  uuid TEXT UNIQUE NOT NULL,              -- globally unique id, safe for offline-generated records
  qr_checksum TEXT NOT NULL,              -- short checksum embedded in the QR payload, checked on scan

  status TEXT NOT NULL DEFAULT 'draft'
    CHECK(status IN ('draft','dispatched','in_transit','received','closed','void')),

  origin_site_id INTEGER NOT NULL REFERENCES sites(id),
  destination_site_id INTEGER REFERENCES sites(id),
  truck_id INTEGER REFERENCES trucks(id),
  driver_id INTEGER REFERENCES drivers(id),
  waste_type_id INTEGER NOT NULL REFERENCES waste_types(id),

  -- Origin capture
  tare_weight_kg REAL,
  estimated_weight_kg REAL,
  time_out TEXT,
  origin_operator_id INTEGER REFERENCES users(id),
  origin_signature TEXT, -- base64 PNG from signature canvas

  -- Destination / weighbridge capture
  gross_weight_kg REAL,
  net_weight_kg REAL,               -- computed: gross - tare, never negative (enforced in app logic)
  rate_per_ton REAL,
  disposal_fee REAL,                -- computed: net_weight_kg / 1000 * rate_per_ton
  time_in_destination TEXT,
  destination_operator_id INTEGER REFERENCES users(id),
  destination_signature TEXT,
  driver_signature TEXT,

  closed_at TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

-- Full audit trail — every lifecycle transition, who did it, and from which device.
-- This is also how offline-created events reconcile: each event carries its own
-- client-generated uuid + timestamp so out-of-order sync doesn't corrupt history.
CREATE TABLE IF NOT EXISTS manifest_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  manifest_id INTEGER NOT NULL REFERENCES manifests(id),
  event_uuid TEXT UNIQUE NOT NULL,
  event_type TEXT NOT NULL, -- created, dispatched, scanned, weighed, closed, voided, synced
  payload_json TEXT,        -- arbitrary event detail, e.g. {"gross_weight_kg": 8200}
  user_id INTEGER REFERENCES users(id),
  device_id TEXT,           -- which tablet/phone recorded this, for offline provenance
  occurred_at TEXT NOT NULL, -- when it ACTUALLY happened on the device (may be before sync)
  synced_at TEXT DEFAULT (datetime('now'))
);

-- Offline sync queue — mirrors what each mobile app keeps in local SQLite/WatermelonDB
-- while offline. Rows land here when a device finally reconnects and pushes its queue.
-- status flow: pending -> applied | conflict | failed
CREATE TABLE IF NOT EXISTS sync_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id TEXT NOT NULL,
  entity_type TEXT NOT NULL,   -- 'manifest' | 'manifest_event'
  entity_uuid TEXT NOT NULL,
  operation TEXT NOT NULL,     -- 'create' | 'update'
  payload_json TEXT NOT NULL,
  client_timestamp TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending','applied','conflict','failed')),
  received_at TEXT DEFAULT (datetime('now')),
  resolved_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_manifests_status ON manifests(status);
CREATE INDEX IF NOT EXISTS idx_manifests_tenant ON manifests(tenant_id);
CREATE INDEX IF NOT EXISTS idx_events_manifest ON manifest_events(manifest_id);
CREATE INDEX IF NOT EXISTS idx_sync_status ON sync_queue(status);
