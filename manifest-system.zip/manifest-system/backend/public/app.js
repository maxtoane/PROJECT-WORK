const S = { token: localStorage.getItem('token'), user: JSON.parse(localStorage.getItem('user')||'null'), route: 'dashboard', manifestFilter:'all', cache:{} };

async function api(path, method, body){
  const opts = { method: method||'GET', headers:{} };
  if (S.token) opts.headers.Authorization = 'Bearer '+S.token;
  if (body){ opts.headers['Content-Type']='application/json'; opts.body=JSON.stringify(body); }
  const res = await fetch(path, opts);
  if (res.status===401){ logout(); throw new Error('Session expired'); }
  const isJson = (res.headers.get('content-type')||'').includes('json');
  const data = isJson ? await res.json() : await res.text();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
async function apiBlob(path){
  const res = await fetch(path, { headers: S.token ? {Authorization:'Bearer '+S.token} : {} });
  if (!res.ok) throw new Error('Failed to load image');
  return URL.createObjectURL(await res.blob());
}

function toast(msg){
  const t = document.getElementById('toast'); if(!t) return;
  t.textContent = msg; t.classList.add('show');
  clearTimeout(window._tt); window._tt=setTimeout(()=>t.classList.remove('show'), 2500);
}

function logout(){ localStorage.removeItem('token'); localStorage.removeItem('user'); S.token=null; S.user=null; render(); }

function nav(route){ S.route = route; render(); }

/* ============ LOGIN ============ */
function loginScreen(){
  return `
  <div class="login-wrap">
    <div class="login-card">
      <div class="brand-badge">W</div>
      <h1>Waste Manifest Control Center</h1>
      <p>Track manifests from origin dispatch to weighbridge closure.</p>
      <form id="loginForm">
        <label>Email</label>
        <input type="email" id="email" placeholder="you@wastetrack.local" required>
        <label>Password</label>
        <input type="password" id="password" placeholder="••••••••" required>
        <button class="btn btn--primary" type="submit">Sign in</button>
      </form>
      <div class="demo-box">
        <b>Demo accounts</b><br>
        admin@wastetrack.local / Admin@123<br>
        origin@wastetrack.local / Origin@123<br>
        weighbridge@wastetrack.local / Weigh@123
      </div>
    </div>
  </div>`;
}

/* ============ SHELL ============ */
function navItems(){
  return [['dashboard','Dashboard'],['manifests','Manifests'],['sites','Sites'],['trucks','Trucks'],['drivers','Drivers'],['wastetypes','Waste Types & Rates']];
}
function shell(inner){
  const initials = (S.user.name||'?').split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
  return `
  <div class="shell">
    <aside class="sidebar">
      <div class="brand"><div class="brand-badge" style="margin:0">W</div><div><b>WasteTrack</b><small>Manifest &amp; Weighbridge</small></div></div>
      <nav>
        ${navItems().map(([id,label])=>`<button data-nav="${id}" class="${S.route===id?'active':''}">${label}</button>`).join('')}
      </nav>
      <div class="foot">Signed in as ${S.user.role.replace('_',' ')}</div>
    </aside>
    <div class="main">
      <div class="topbar">
        <div class="who"><div class="avatar">${initials}</div><div><div>${S.user.name}</div><div class="role">${S.user.role.replace('_',' ')}</div></div></div>
        <button class="btn btn--ghost" id="logoutBtn">Log out</button>
      </div>
      <div class="content">${inner}</div>
    </div>
  </div>
  <div class="toast" id="toast"></div>`;
}

/* ============ DASHBOARD ============ */
async function dashboardPage(){
  const [summary, manifests] = await Promise.all([ api('/api/reports/summary'), api('/api/manifests') ]);
  const latest = manifests.slice(0,6);
  return `
    <div class="pagehead">
      <div><div class="eyebrow">Control center</div><h1>Operations dashboard</h1><p>Live view of manifests across every site.</p></div>
    </div>
    <div class="stat-grid">
      <div class="stat-card"><div class="label">Total manifests</div><div class="value">${summary.total_manifests}</div><div class="meta">${summary.open_count} open · ${summary.closed_count} closed</div></div>
      <div class="stat-card"><div class="label">Open in pipeline</div><div class="value">${summary.open_count}</div><div class="meta">Draft, dispatched, in transit or received</div></div>
      <div class="stat-card"><div class="label">Total tonnage closed</div><div class="value">${(summary.total_tonnage_kg/1000).toFixed(2)}t</div><div class="meta">Net weight, closed manifests only</div></div>
      <div class="stat-card"><div class="label">Total revenue</div><div class="value">GHS ${summary.total_revenue.toFixed(2)}</div><div class="meta">Disposal fees collected</div></div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Latest manifests</h2><a href="#" data-nav="manifests" style="font-size:12.5px;font-weight:600;color:var(--brand)">View all →</a></div>
      ${manifestTable(latest)}
    </div>`;
}

function manifestTable(rows){
  if (!rows.length) return `<div class="empty">No manifests yet. Create the first one from the Manifests page.</div>`;
  return `<table><thead><tr><th>Manifest</th><th>Route</th><th>Truck / Driver</th><th>Waste type</th><th>Status</th><th>Net weight</th></tr></thead>
    <tbody>${rows.map(m=>`
      <tr data-open-manifest="${m.id}">
        <td><b>${m.manifest_number}</b></td>
        <td>${m.origin_name||'—'} → ${m.destination_name||'—'}</td>
        <td>${m.plate_no||'—'} · ${m.driver_name||'—'}</td>
        <td>${m.waste_type_name||''}</td>
        <td><span class="pill pill--${m.status}">${m.status.replace('_',' ')}</span></td>
        <td>${m.net_weight_kg!=null ? m.net_weight_kg+' kg' : '—'}</td>
      </tr>`).join('')}</tbody></table>`;
}

/* ============ MANIFESTS LIST ============ */
async function manifestsPage(){
  const rows = await api('/api/manifests' + (S.manifestFilter!=='all' ? '?status='+S.manifestFilter : ''));
  const statuses = ['all','draft','dispatched','in_transit','received','closed','void'];
  return `
    <div class="pagehead">
      <div><div class="eyebrow">Operations</div><h1>Manifests</h1><p>Every trip ticket, from creation to closure.</p></div>
      <button class="btn btn--primary" id="newManifestBtn">+ New manifest</button>
    </div>
    <div class="filter-row">${statuses.map(s=>`<button class="chip ${S.manifestFilter===s?'active':''}" data-filter="${s}">${s.replace('_',' ')}</button>`).join('')}</div>
    <div class="panel">${manifestTable(rows)}</div>`;
}

/* ============ MASTER DATA (Sites / Trucks / Drivers / Waste types) ============ */
async function sitesPage(){
  const rows = await api('/api/sites');
  return `<div class="pagehead"><div><div class="eyebrow">Master data</div><h1>Sites</h1><p>Generator sites, sorting stations and landfills.</p></div>
    <button class="btn btn--primary" id="addSiteBtn">+ Add site</button></div>
    <div class="panel"><table><thead><tr><th>Name</th><th>Type</th><th>Address</th></tr></thead>
    <tbody>${rows.map(s=>`<tr><td><b>${s.name}</b></td><td>${s.site_type.replace('_',' ')}</td><td>${s.address||'—'}</td></tr>`).join('') || '<tr><td colspan=3 class="empty">No sites yet</td></tr>'}</tbody></table></div>`;
}
async function trucksPage(){
  const rows = await api('/api/trucks');
  return `<div class="pagehead"><div><div class="eyebrow">Master data</div><h1>Trucks</h1><p>Fleet available for dispatch.</p></div>
    <button class="btn btn--primary" id="addTruckBtn">+ Add truck</button></div>
    <div class="panel"><table><thead><tr><th>Plate no.</th><th>Carrier</th><th>Capacity</th></tr></thead>
    <tbody>${rows.map(t=>`<tr><td><b>${t.plate_no}</b></td><td>${t.carrier||'—'}</td><td>${t.capacity_kg?t.capacity_kg+' kg':'—'}</td></tr>`).join('') || '<tr><td colspan=3 class="empty">No trucks yet</td></tr>'}</tbody></table></div>`;
}
async function driversPage(){
  const rows = await api('/api/drivers');
  return `<div class="pagehead"><div><div class="eyebrow">Master data</div><h1>Drivers</h1><p>Everyone certified to run a manifest trip.</p></div>
    <button class="btn btn--primary" id="addDriverBtn">+ Add driver</button></div>
    <div class="panel"><table><thead><tr><th>Name</th><th>Phone</th><th>Licence no.</th></tr></thead>
    <tbody>${rows.map(d=>`<tr><td><b>${d.name}</b></td><td>${d.phone||'—'}</td><td>${d.licence_no||'—'}</td></tr>`).join('') || '<tr><td colspan=3 class="empty">No drivers yet</td></tr>'}</tbody></table></div>`;
}
async function wasteTypesPage(){
  const [types, rates] = await Promise.all([ api('/api/waste-types'), api('/api/rates') ]);
  return `<div class="pagehead"><div><div class="eyebrow">Master data</div><h1>Waste types &amp; rates</h1><p>Configurable per site — used automatically when a manifest is closed.</p></div>
    <button class="btn btn--primary" id="addRateBtn">+ Add rate</button></div>
    <div class="panel"><div class="panel-head"><h2>Configured rates</h2></div><table><thead><tr><th>Site</th><th>Waste type</th><th>Rate</th></tr></thead>
    <tbody>${rates.map(r=>`<tr><td>${r.site_name}</td><td>${r.waste_type_name}</td><td>${r.currency} ${r.rate_per_ton.toFixed(2)} / ton</td></tr>`).join('') || '<tr><td colspan=3 class="empty">No rates configured</td></tr>'}</tbody></table></div>
    <div class="panel"><div class="panel-head"><h2>Waste types</h2></div><table><thead><tr><th>Name</th></tr></thead>
    <tbody>${types.map(t=>`<tr><td>${t.name}</td></tr>`).join('')}</tbody></table></div>`;
}

/* ============ MANIFEST DETAIL MODAL ============ */
async function openManifestModal(id){
  const m = await api('/api/manifests/'+id);
  const qrUrl = await apiBlob('/api/manifests/'+id+'/qr').catch(()=>null);
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal">
      <div class="modal-head"><h3>${m.manifest_number} <span class="pill pill--${m.status}">${m.status.replace('_',' ')}</span></h3><button class="icon-btn" data-close>✕</button></div>
      <div class="modal-body">
        <p style="margin-top:0;color:var(--muted);font-size:13px">${m.origin_name||'—'} → ${m.destination_name||'—'} · ${m.plate_no||'—'} · ${m.driver_name||'—'}</p>
        <div class="form-grid" style="font-size:13px">
          <div><b>Waste type</b><div>${m.waste_type_name||'—'}</div></div>
          <div><b>Tare weight</b><div>${m.tare_weight_kg||'—'} kg</div></div>
          <div><b>Gross weight</b><div>${m.gross_weight_kg||'—'} kg</div></div>
          <div><b>Net weight</b><div>${m.net_weight_kg||'—'} kg</div></div>
          <div><b>Rate</b><div>${m.rate_per_ton?m.rate_per_ton+' / ton':'—'}</div></div>
          <div><b>Disposal fee</b><div>${m.disposal_fee!=null?'GHS '+m.disposal_fee.toFixed(2):'—'}</div></div>
        </div>
        ${qrUrl ? `<div class="qr-box"><img src="${qrUrl}"><div style="font-size:11.5px;color:var(--brand-dark);margin-top:6px">Scan at destination weighbridge</div></div>` : ''}
        <div class="panel-head" style="margin-top:16px"><h2>Timeline</h2></div>
        <div class="timeline">${m.events.map(e=>`<div class="tl-item"><div class="tl-dot"></div><div><div class="type">${e.event_type.replace('_',' ')}</div><div class="when">${e.occurred_at}</div></div></div>`).join('')}</div>
      </div>
      <div class="modal-foot">
        ${m.status==='draft' ? `<button class="btn btn--primary" data-action="dispatch" data-id="${m.id}">Dispatch shipment</button>` : ''}
        ${(m.status==='in_transit'||m.status==='received') ? `<button class="btn btn--primary" data-action="weigh" data-id="${m.id}">Weigh &amp; close</button>` : ''}
        <button class="btn btn--ghost" data-close>Close</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e=>{
    if (e.target===overlay || e.target.closest('[data-close]')) overlay.remove();
    if (e.target.closest('[data-action="dispatch"]')) doDispatch(m.id, overlay);
    if (e.target.closest('[data-action="weigh"]')) { overlay.remove(); openWeighModal(m.id); }
  });
}

async function doDispatch(id, overlay){
  try{ await api('/api/manifests/'+id+'/dispatch','POST',{origin_signature:'demo-signature'}); toast('Shipment dispatched'); overlay.remove(); render(); }
  catch(e){ toast(e.message); }
}

function openWeighModal(id){
  const overlay = document.createElement('div');
  overlay.className='modal-overlay';
  overlay.innerHTML = `<div class="modal"><div class="modal-head"><h3>Weigh &amp; close</h3><button class="icon-btn" data-close>✕</button></div>
    <div class="modal-body"><label style="display:block;margin-bottom:6px;font-size:12.5px;font-weight:600;color:var(--muted)">Gross weight (kg)</label>
    <input type="number" id="grossWeight" style="width:100%" placeholder="e.g. 9200" required></div>
    <div class="modal-foot"><button class="btn btn--ghost" data-close>Cancel</button><button class="btn btn--primary" id="confirmWeigh">Close manifest</button></div></div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', async e=>{
    if (e.target===overlay || e.target.closest('[data-close]')) overlay.remove();
    if (e.target.id==='confirmWeigh'){
      const gross = document.getElementById('grossWeight').value;
      if (!gross) return;
      try{ await api('/api/manifests/'+id+'/weigh','POST',{gross_weight_kg:Number(gross), destination_signature:'demo', driver_signature:'demo'}); toast('Manifest closed'); overlay.remove(); render(); }
      catch(err){ toast(err.message); }
    }
  });
}

/* ============ NEW MANIFEST MODAL ============ */
async function openNewManifestModal(){
  const [sites, trucks, drivers, wasteTypes] = await Promise.all([api('/api/sites'), api('/api/trucks'), api('/api/drivers'), api('/api/waste-types')]);
  const overlay = document.createElement('div');
  overlay.className='modal-overlay';
  overlay.innerHTML = `<div class="modal"><div class="modal-head"><h3>New manifest</h3><button class="icon-btn" data-close>✕</button></div>
    <form class="modal-body form-grid" id="newManifestForm">
      <label>Origin site<select name="origin_site_id" required>${sites.map(s=>`<option value="${s.id}">${s.name}</option>`).join('')}</select></label>
      <label>Destination site<select name="destination_site_id">${sites.map(s=>`<option value="${s.id}">${s.name}</option>`).join('')}</select></label>
      <label>Truck<select name="truck_id">${trucks.map(t=>`<option value="${t.id}">${t.plate_no}</option>`).join('')}</select></label>
      <label>Driver<select name="driver_id">${drivers.map(d=>`<option value="${d.id}">${d.name}</option>`).join('')}</select></label>
      <label>Waste type<select name="waste_type_id" required>${wasteTypes.map(w=>`<option value="${w.id}">${w.name}</option>`).join('')}</select></label>
      <label>Tare weight (kg)<input type="number" name="tare_weight_kg" required></label>
      <label class="full">Estimated weight (kg)<input type="number" name="estimated_weight_kg"></label>
    </form>
    <div class="modal-foot"><button class="btn btn--ghost" data-close>Cancel</button><button class="btn btn--primary" id="submitManifest">Create</button></div></div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', async e=>{
    if (e.target===overlay || e.target.closest('[data-close]')) overlay.remove();
    if (e.target.id==='submitManifest'){
      const fd = new FormData(document.getElementById('newManifestForm'));
      const body = Object.fromEntries(fd.entries());
      try{ await api('/api/manifests','POST',body); toast('Manifest created'); overlay.remove(); render(); }
      catch(err){ toast(err.message); }
    }
  });
}

/* ============ SIMPLE ADD-FORM MODALS for master data ============ */
function openSimpleModal(title, fields, onSubmit){
  const overlay = document.createElement('div');
  overlay.className='modal-overlay';
  overlay.innerHTML = `<div class="modal"><div class="modal-head"><h3>${title}</h3><button class="icon-btn" data-close>✕</button></div>
    <form class="modal-body form-grid" id="simpleForm">
      ${fields.map(f=>`<label class="${f.full?'full':''}">${f.label}<input name="${f.name}" type="${f.type||'text'}" ${f.required?'required':''}></label>`).join('')}
    </form>
    <div class="modal-foot"><button class="btn btn--ghost" data-close>Cancel</button><button class="btn btn--primary" id="simpleSubmit">Save</button></div></div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', async e=>{
    if (e.target===overlay || e.target.closest('[data-close]')) overlay.remove();
    if (e.target.id==='simpleSubmit'){
      const fd = new FormData(document.getElementById('simpleForm'));
      try{ await onSubmit(Object.fromEntries(fd.entries())); toast('Saved'); overlay.remove(); render(); }
      catch(err){ toast(err.message); }
    }
  });
}

/* ============ RENDER / ROUTER ============ */
async function render(){
  const el = document.getElementById('app');
  if (!S.token){ el.innerHTML = loginScreen(); bindLogin(); return; }

  let inner = '<div class="empty">Loading…</div>';
  el.innerHTML = shell(inner);
  bindShell();

  try{
    if (S.route==='dashboard') inner = await dashboardPage();
    else if (S.route==='manifests') inner = await manifestsPage();
    else if (S.route==='sites') inner = await sitesPage();
    else if (S.route==='trucks') inner = await trucksPage();
    else if (S.route==='drivers') inner = await driversPage();
    else if (S.route==='wastetypes') inner = await wasteTypesPage();
  }catch(e){ inner = `<div class="empty">${e.message}</div>`; }

  document.querySelector('.content').innerHTML = inner;
  bindContent();
}

function bindLogin(){
  document.getElementById('loginForm').addEventListener('submit', async e=>{
    e.preventDefault();
    try{
      const d = await api('/api/auth/login','POST',{email:document.getElementById('email').value, password:document.getElementById('password').value});
      S.token=d.token; S.user=d.user; localStorage.setItem('token',d.token); localStorage.setItem('user',JSON.stringify(d.user));
      render();
    }catch(err){ toast(err.message); }
  });
}
function bindShell(){
  document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click', e=>{ e.preventDefault(); nav(b.dataset.nav); }));
  const lo = document.getElementById('logoutBtn'); if(lo) lo.addEventListener('click', logout);
}
function bindContent(){
  document.querySelectorAll('[data-open-manifest]').forEach(r=>r.addEventListener('click', ()=>openManifestModal(r.dataset.openManifest)));
  document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click', e=>{ e.preventDefault(); nav(b.dataset.nav); }));
  const nm = document.getElementById('newManifestBtn'); if(nm) nm.addEventListener('click', openNewManifestModal);
  document.querySelectorAll('[data-filter]').forEach(c=>c.addEventListener('click', ()=>{ S.manifestFilter=c.dataset.filter; render(); }));

  const addSite = document.getElementById('addSiteBtn');
  if (addSite) addSite.addEventListener('click', ()=> openSimpleModal('Add site', [
    {name:'name',label:'Name',required:true},
    {name:'site_type',label:'Type (generator / sorting_station / landfill)',required:true},
    {name:'address',label:'Address',full:true}
  ], body=>api('/api/sites','POST',body)));

  const addTruck = document.getElementById('addTruckBtn');
  if (addTruck) addTruck.addEventListener('click', ()=> openSimpleModal('Add truck', [
    {name:'plate_no',label:'Plate number',required:true},
    {name:'carrier',label:'Carrier'},
    {name:'capacity_kg',label:'Capacity (kg)',type:'number'}
  ], body=>api('/api/trucks','POST',body)));

  const addDriver = document.getElementById('addDriverBtn');
  if (addDriver) addDriver.addEventListener('click', ()=> openSimpleModal('Add driver', [
    {name:'name',label:'Name',required:true},
    {name:'phone',label:'Phone'},
    {name:'licence_no',label:'Licence number'}
  ], body=>api('/api/drivers','POST',body)));

  const addRate = document.getElementById('addRateBtn');
  if (addRate) addRate.addEventListener('click', ()=> openSimpleModal('Add rate', [
    {name:'site_id',label:'Site ID',required:true,type:'number'},
    {name:'waste_type_id',label:'Waste type ID',required:true,type:'number'},
    {name:'rate_per_ton',label:'Rate per ton',required:true,type:'number'}
  ], body=>api('/api/rates','POST',body)));
}

render();
